"""
Central configuration for the AI-Based Autonomous Navigation System.

Keeping simulation parameters in a dedicated configuration file makes the
project easier to maintain, experiment with, and extend.
"""

# =========================================================
# GRID / ENVIRONMENT CONFIGURATION
# =========================================================

GRID_WIDTH = 30
GRID_HEIGHT = 20

# Size of one grid cell on screen, in pixels.
CELL_SIZE = 30


# =========================================================
# USER INTERFACE CONFIGURATION
# =========================================================

SIDEBAR_WIDTH = 300

SCREEN_WIDTH = GRID_WIDTH * CELL_SIZE + SIDEBAR_WIDTH
SCREEN_HEIGHT = GRID_HEIGHT * CELL_SIZE

FPS = 30


# =========================================================
# ROBOT MISSION CONFIGURATION
# =========================================================

# Starting grid coordinate of the autonomous robot.
START = (1, 1)

# Destination that the robot must reach autonomously.
GOAL = (28, 18)


# =========================================================
# PERCEPTION CONFIGURATION
# =========================================================

# Number of grid cells around the robot that can be sensed.
#
# This acts as a simplified simulation of a LiDAR/range sensor.
SENSOR_RADIUS = 5


# =========================================================
# NAVIGATION CONFIGURATION
# =========================================================

# Controls animation speed.
#
# The robot performs one navigation movement after this many
# rendered simulation frames.
MOVE_EVERY_N_FRAMES = 5


# Even if no obvious obstacle blocks the path, periodically running
# the planner allows the system to adapt to environmental changes.
PERIODIC_REPLAN_STEPS = 8


# =========================================================
# OUTPUT CONFIGURATION
# =========================================================

OUTPUT_DIRECTORY = "outputs"