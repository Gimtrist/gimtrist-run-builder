"""
Entry point for the AI-Based Autonomous Navigation System.
"""

from src.simulation.simulator import Simulator


def main():
    """
    Start the autonomous-navigation simulation.
    """

    simulator = Simulator()

    simulator.run()


if __name__ == "__main__":
    main()