# 🤖 AI-Based Autonomous Navigation System

A modular autonomous-navigation simulator built in Python that demonstrates environment perception, occupancy-grid mapping, A* path planning, dynamic obstacle handling, automatic replanning, collision prevention, autonomous waypoint navigation, telemetry, and automated testing.

---

## 🚀 Project Overview

Autonomous robots must be capable of understanding their surroundings, finding a safe route toward a destination, and adapting when the environment changes.

This project implements these concepts in a virtual 2D simulation without requiring physical robotics hardware.

The virtual robot continuously performs the following autonomous loop:

**Sense → Map → Plan → Move → Detect Changes → Replan → Reach Goal**

The project is designed as a student portfolio implementation of fundamental concepts used in autonomous mobile robots, warehouse robotics, autonomous vehicles, delivery systems, and smart mobility platforms.

---

## 🎯 Problem Statement

Traditional robots often depend on predefined routes or human control.

Real autonomous systems must instead be capable of:

- detecting obstacles
- representing their environment
- determining a safe route
- navigating toward a target
- responding to newly discovered obstacles
- adapting to moving obstacles
- preventing unsafe movements
- replanning when conditions change

This project demonstrates a simplified implementation of that complete navigation pipeline.

---

## 🏭 Industry Relevance

Similar navigation principles are used in:

- Autonomous Mobile Robots (AMRs)
- warehouse automation
- autonomous vehicles
- delivery robots
- industrial transportation systems
- drones
- hospital robots
- mining robots
- inspection robots
- smart mobility platforms

The simulation provides a hardware-free environment for studying the software architecture behind autonomous navigation.

---

## 🧠 Core Features

- 2D occupancy-grid environment
- simulated range/LiDAR-style perception
- incremental obstacle discovery
- A* path-planning algorithm
- Manhattan-distance heuristic
- autonomous waypoint navigation
- dynamic moving obstacle
- automatic route replanning
- collision validation
- real-time visualization
- real-time mission telemetry
- autonomous goal detection
- experiment metrics
- final-run screenshot generation
- 13 automated unit tests
- modular software architecture

---

## 🛠 Tech Stack

| Technology | Purpose |
|---|---|
| Python 3.11.9 | Main development language |
| NumPy | Occupancy-grid representation |
| Pygame-CE | 2D simulation and visualization |
| A* Search | Intelligent path planning |
| Pytest | Automated testing |
| Git | Version control |
| GitHub | Project documentation and proof of work |

---

## 🏗 System Architecture

```text
Virtual Environment
        │
        ▼
Range Sensor
        │
        ▼
Obstacle Detection
        │
        ▼
Occupancy Knowledge
        │
        ▼
A* Path Planner
        │
        ▼
Navigation Controller
        │
        ▼
Collision Validation
        │
   ┌────┴────┐
   │         │
 CLEAR     BLOCKED
   │         │
   ▼         ▼
 MOVE      REPLAN
   │         │
   └────┬────┘
        ▼
Visualization + Metrics
```

Detailed architecture documentation is available in:

```text
docs/architecture.md
```

---

## 🔄 Navigation Pipeline

The autonomous robot repeatedly performs:

```text
1. Read the environment using simulated range perception
2. Detect nearby static and dynamic obstacles
3. Update the robot's known occupancy map
4. Generate a route using A*
5. Select the next waypoint
6. Validate the movement
7. Move one grid position
8. Scan the environment again
9. Replan when the route becomes invalid
10. Continue until the destination is reached
```

---

## 📁 Project Structure

```text
AI-Autonomous-Navigation-System/
│
├── assets/
│   ├── screenshots/
│   │   ├── 01_project_structure.png
│   │   ├── 02_simulation_environment.png
│   │   ├── 03_astar_path_planning.png
│   │   ├── 04_obstacle_perception.png
│   │   ├── 05_dynamic_replanning.png
│   │   ├── 06_navigation_success.png
│   │   ├── 07_terminal_metrics.png
│   │   └── 08_pytest_results.png
│   │
│   └── videos/
│       └── autonomous_navigation_demo.mp4
│
├── config/
│   ├── __init__.py
│   └── settings.py
│
├── docs/
│   └── architecture.md
│
├── outputs/
│   ├── final_run.png
│   └── run_metrics.json
│
├── src/
│   ├── __init__.py
│   │
│   ├── map/
│   │   ├── __init__.py
│   │   └── grid_map.py
│   │
│   ├── perception/
│   │   ├── __init__.py
│   │   └── range_sensor.py
│   │
│   ├── planning/
│   │   ├── __init__.py
│   │   └── astar.py
│   │
│   ├── navigation/
│   │   ├── __init__.py
│   │   └── controller.py
│   │
│   └── simulation/
│       ├── __init__.py
│       └── simulator.py
│
├── tests/
│   ├── __init__.py
│   ├── test_astar.py
│   ├── test_controller.py
│   └── test_range_sensor.py
│
├── .gitignore
├── LICENSE
├── main.py
├── README.md
└── requirements.txt
```

---

## ⚙️ Installation

This project was developed using:

```text
Python 3.11.9
```

### 1. Clone the Repository

```bash
git clone https://github.com/SahilRamteke67/AI-Autonomous-Navigation-System.git
```

Move into the project:

```bash
cd AI-Autonomous-Navigation-System
```

### 2. Create a Virtual Environment

#### Windows

```powershell
python -m venv .venv
```

Activate:

```powershell
.venv\Scripts\Activate.ps1
```

#### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

---

## ▶️ Running the Simulator

Run:

```bash
python main.py
```

The autonomous robot will automatically:

- scan nearby obstacles
- update environment knowledge
- generate an A* route
- move toward the destination
- detect newly visible obstacles
- respond to a moving obstacle
- replan when necessary
- reach the goal

No manual driving is required.

Press:

```text
ESC
```

to close the simulator.

---

## 🧪 Running Tests

Run:

```bash
python -m pytest -v
```

The current project contains:

```text
13 automated tests
```

The tests verify:

### A* Planner

- basic route generation
- obstacle avoidance
- start-equals-goal handling
- no-path handling

### Navigation Controller

- path storage
- next-waypoint selection
- blocked-route detection
- clear-route detection
- goal detection

### Range Sensor

- nearby static obstacle detection
- dynamic obstacle detection
- sensor-boundary behavior

---

## 📊 Generated Results

A completed simulation creates:

```text
outputs/run_metrics.json
outputs/final_run.png
```

Example metrics from a successful run:

```json
{
    "status": "success",
    "start": [
        1,
        1
    ],
    "goal": [
        28,
        18
    ],
    "steps": 52,
    "total_distance_units": 52,
    "replans_total": 9,
    "successful_replans": 9,
    "failed_replans": 0,
    "collisions_prevented": 0,
    "known_static_obstacles": 81,
    "sensor_radius": 5,
    "execution_seconds": 8.56
}
```

Values may vary slightly between runs.

---

## 📸 Simulation Results

### Project Structure

![Project Structure](assets/screenshots/01_project_structure.png)

---

### Virtual Simulation Environment

![Simulation Environment](assets/screenshots/02_simulation_environment.png)

---

### A* Path Planning

![A Star Path Planning](assets/screenshots/03_astar_path_planning.png)

---

### Obstacle Perception

![Obstacle Perception](assets/screenshots/04_obstacle_perception.png)

---

### Dynamic Navigation and Replanning

![Dynamic Replanning](assets/screenshots/05_dynamic_replanning.png)

---

### Successful Autonomous Navigation

![Navigation Success](assets/screenshots/06_navigation_success.png)

---

### Terminal Metrics

![Terminal Metrics](assets/screenshots/07_terminal_metrics.png)

---

### Automated Test Results

![Pytest Results](assets/screenshots/08_pytest_results.png)

---

## 🎥 Demo Video

A screen-recorded demonstration of the complete autonomous-navigation pipeline is included in the repository.

Demo file:

```text
assets/videos/autonomous_navigation_demo.mp4
```

The video demonstrates:

- simulator execution
- autonomous robot movement
- A* path planning
- simulated range perception
- obstacle discovery
- dynamic obstacle handling
- route replanning
- successful goal completion
- mission telemetry

---

## 🧠 A* Path Planning

The planner uses the A* search algorithm:

```text
f(n) = g(n) + h(n)
```

where:

- `g(n)` represents the cost already travelled
- `h(n)` estimates the remaining distance
- `f(n)` represents the estimated total path cost

Manhattan distance is used as the heuristic:

```text
h = |x1 - x2| + |y1 - y2|
```

This heuristic is appropriate because the robot operates on a four-connected grid.

The robot can currently move:

```text
Up
Down
Left
Right
```

---

## 📡 Perception

The simulated range sensor detects obstacles within a configurable sensor radius.

The current sensor radius is:

```text
5 grid cells
```

Static obstacles that have already been observed are retained in the robot's internal environment knowledge.

Dynamic obstacles are treated as temporary observations because their positions can change.

This creates a simplified version of the perception-to-planning pipeline used by autonomous robotic systems.

---

## 🔁 Dynamic Replanning

The robot does not blindly follow the first route calculated at mission start.

When environmental conditions affect the active route:

```text
Obstacle Detected
        ↓
Current Path Evaluated
        ↓
Route Becomes Invalid
        ↓
A* Executed Again
        ↓
Alternative Path Generated
        ↓
Robot Continues
```

The simulator also performs periodic replanning so that navigation can remain responsive to changing environmental conditions.

---

## 🛡 Collision Prevention

Before executing each waypoint movement, the simulator performs a safety validation.

If the requested next position is occupied:

```text
Unsafe Movement Detected
        ↓
Movement Rejected
        ↓
Collision Prevented
        ↓
Environment Knowledge Updated
        ↓
Route Replanned
```

This provides an additional safety layer before movement is executed.

---

## 📈 Mission Telemetry

The simulation interface displays:

- robot position
- goal position
- movement steps
- distance travelled
- total replans
- successful replans
- failed replans
- collisions prevented
- known obstacles
- sensor radius
- mission status

Mission results are automatically saved after successful completion.

---

## 📚 Learning Outcomes

This project helped develop practical understanding of:

- autonomous-navigation architecture
- robotics simulation
- occupancy grids
- environment perception
- graph-search algorithms
- A* path planning
- heuristic functions
- dynamic obstacle handling
- autonomous waypoint navigation
- automatic replanning
- navigation controllers
- collision checking
- feedback-driven systems
- software modularity
- automated testing
- mission telemetry
- Git/GitHub project organization

---

## ⚠️ Current Limitations

The current system is a simplified autonomous-navigation simulator and not a production self-driving vehicle or complete robotics stack.

Current limitations include:

- 2D environment
- discrete grid movement
- four-direction navigation
- perfect robot localization
- simplified range-sensor model
- no sensor noise
- no continuous vehicle dynamics
- no camera-based perception
- no SLAM
- no ROS
- no physical robot interface

These limitations were intentionally selected so that the complete navigation pipeline could run on a standard laptop.

---

## 🚀 Future Improvements

Planned extensions include:

- OpenCV camera perception
- YOLO object detection
- ROS 2 integration
- Webots simulation
- Gazebo simulation
- CARLA autonomous-driving simulation
- SLAM
- LiDAR point-cloud processing
- D* Lite dynamic planning
- Dijkstra comparison
- RRT / RRT*
- Hybrid A*
- reinforcement-learning navigation
- PID control
- Pure Pursuit trajectory tracking
- autonomous warehouse robot environment
- multi-agent navigation
- cloud telemetry dashboard
- real robot deployment

---

## 🗺 Development Roadmap

### Version 1 — Current Version

- Python
- Pygame-CE
- occupancy-grid environment
- simulated range perception
- A* path planning
- autonomous waypoint navigation
- dynamic obstacle handling
- automatic replanning
- collision validation
- mission telemetry
- automated testing

### Version 2 — Algorithm Comparison

- A*
- Dijkstra
- D* Lite
- planning-time comparison
- path-length comparison

### Version 3 — Robotics Simulation

- Webots
- ROS 2
- simulated LiDAR
- realistic robot motion

### Version 4 — Mapping and Localization

- SLAM
- localization
- navigation cost maps
- advanced planners

### Version 5 — Visual Perception

- OpenCV
- YOLO
- object detection
- visual obstacle perception

### Version 6 — Advanced Deployment

- CARLA autonomous-driving simulation
- physical robot integration

---

## 👨‍💻 Author

**Sahil Ramteke**

Engineering student interested in:

- Artificial Intelligence
- Autonomous Systems
- Robotics
- Simulation
- Technology and Product Development

This project was developed as a practical proof-of-work implementation for learning autonomous-navigation concepts and demonstrating engineering skills through GitHub.

---

## ⭐ Project Goal

The objective is not simply to create an animation.

The project demonstrates how multiple autonomous-system components can be integrated into a working software pipeline:

**Perception → Mapping → Planning → Decision Making → Navigation → Safety Validation → Feedback**