"""
Navigation controller.

This module converts a planned A* path into movement decisions for the
autonomous robot.
"""

from typing import List, Optional, Set, Tuple


GridPosition = Tuple[int, int]


class NavigationController:
    """
    Controls robot movement along a planned path.

    Responsibilities:
    - store the latest planned path
    - choose the next waypoint
    - detect when the path is blocked
    - keep navigation synchronized with robot position
    """

    def __init__(self):
        self.path: List[GridPosition] = []

    def update_path(
        self,
        new_path: Optional[List[GridPosition]],
    ) -> None:
        """
        Replace the current navigation path.

        If no path exists, store an empty list.
        """

        self.path = new_path or []

    def clear_path(self) -> None:
        """
        Remove the currently stored path.
        """

        self.path = []

    def has_path(self) -> bool:
        """
        Return True when there is at least one future waypoint.
        """

        return len(self.path) > 1

    def next_waypoint(
        self,
        current_position: GridPosition,
    ) -> Optional[GridPosition]:
        """
        Return the next waypoint after the robot's current position.

        If the robot's current position is not found inside the path,
        or there is no future waypoint, return None.
        """

        if not self.path:
            return None

        if current_position not in self.path:
            return None

        current_index = self.path.index(
            current_position
        )

        next_index = current_index + 1

        if next_index >= len(self.path):
            return None

        return self.path[next_index]

    def path_contains_obstacle(
        self,
        blocked_positions: Set[GridPosition],
    ) -> bool:
        """
        Check whether any blocked cell lies on the current route.
        """

        return any(
            position in blocked_positions
            for position in self.path
        )

    def remaining_path(
        self,
        current_position: GridPosition,
    ) -> List[GridPosition]:
        """
        Return the part of the route that still remains.

        Useful later for visualization and debugging.
        """

        if current_position not in self.path:
            return []

        current_index = self.path.index(
            current_position
        )

        return self.path[current_index:]

    def goal_reached(
        self,
        current_position: GridPosition,
        goal: GridPosition,
    ) -> bool:
        """
        Return True when robot reaches the destination.
        """

        return current_position == goal