"""
Main Pygame simulation for the AI-Based Autonomous Navigation System.

This module integrates:
- occupancy-grid environment
- simulated range perception
- A* path planning
- autonomous navigation control
- dynamic obstacles
- collision prevention
- route replanning
- visualization
- navigation telemetry
- experiment metrics
- result saving
"""

import json
import os
import time
from typing import List, Set, Tuple

import pygame

from config.settings import (
    CELL_SIZE,
    FPS,
    GOAL,
    GRID_HEIGHT,
    GRID_WIDTH,
    MOVE_EVERY_N_FRAMES,
    OUTPUT_DIRECTORY,
    PERIODIC_REPLAN_STEPS,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    SENSOR_RADIUS,
    SIDEBAR_WIDTH,
    START,
)
from src.map.grid_map import GridMap
from src.navigation.controller import NavigationController
from src.perception.range_sensor import RangeSensor
from src.planning.astar import AStarPlanner


GridPosition = Tuple[int, int]


class Simulator:
    """
    Main autonomous-navigation simulator.

    Autonomous loop:

    Sense
      ↓
    Update environment knowledge
      ↓
    Plan route
      ↓
    Select waypoint
      ↓
    Validate safety
      ↓
    Move
      ↓
    Detect changes
      ↓
    Replan if required
    """

    def __init__(self):
        pygame.init()

        # =====================================================
        # DISPLAY
        # =====================================================

        self.screen = pygame.display.set_mode(
            (
                SCREEN_WIDTH,
                SCREEN_HEIGHT,
            )
        )

        pygame.display.set_caption(
            "AI-Based Autonomous Navigation System"
        )

        self.clock = pygame.time.Clock()

        self.title_font = pygame.font.SysFont(
            "arial",
            22,
            bold=True,
        )

        self.section_font = pygame.font.SysFont(
            "arial",
            17,
            bold=True,
        )

        self.small_font = pygame.font.SysFont(
            "arial",
            14,
        )

        # =====================================================
        # CORE SYSTEM MODULES
        # =====================================================

        self.world = GridMap(
            GRID_WIDTH,
            GRID_HEIGHT,
        )

        self.sensor = RangeSensor(
            radius=SENSOR_RADIUS,
        )

        self.planner = AStarPlanner(
            width=GRID_WIDTH,
            height=GRID_HEIGHT,
        )

        self.controller = NavigationController()

        # =====================================================
        # ROBOT STATE
        # =====================================================

        self.robot_position: GridPosition = START

        self.goal: GridPosition = GOAL

        self.known_static_obstacles: Set[
            GridPosition
        ] = set()

        self.visible_dynamic_obstacles: Set[
            GridPosition
        ] = set()

        # =====================================================
        # DYNAMIC OBSTACLE
        # =====================================================

        self.dynamic_x = 11
        self.dynamic_y = 7
        self.dynamic_direction = 1

        # =====================================================
        # METRICS
        # =====================================================

        self.steps = 0
        self.total_distance = 0

        self.replans = 0
        self.successful_replans = 0
        self.failed_replans = 0

        self.collisions_prevented = 0

        self.start_time = time.time()

        self.goal_reached = False
        self.results_saved = False

        self.frame_counter = 0

        self.status_message = (
            "Initializing autonomous navigation..."
        )

        # =====================================================
        # OUTPUT DIRECTORY
        # =====================================================

        os.makedirs(
            OUTPUT_DIRECTORY,
            exist_ok=True,
        )

        self.perform_sensor_scan()
        self.replan()

    # =========================================================
    # DYNAMIC OBSTACLE
    # =========================================================

    @property
    def dynamic_obstacles(
        self,
    ) -> Set[GridPosition]:

        return {
            (
                self.dynamic_x,
                self.dynamic_y,
            )
        }

    def update_dynamic_obstacle(
        self,
    ) -> None:

        candidate_x = (
            self.dynamic_x
            + self.dynamic_direction
        )

        if (
            candidate_x > 20
            or candidate_x < 11
        ):
            self.dynamic_direction *= -1

            candidate_x = (
                self.dynamic_x
                + self.dynamic_direction
            )

        candidate_position = (
            candidate_x,
            self.dynamic_y,
        )

        if (
            candidate_position
            not in self.world.static_obstacles
            and candidate_position
            != self.robot_position
            and candidate_position
            != self.goal
        ):
            self.dynamic_x = candidate_x

        else:
            self.dynamic_direction *= -1

    # =========================================================
    # PERCEPTION
    # =========================================================

    def perform_sensor_scan(
        self,
    ) -> None:

        (
            visible_static,
            visible_dynamic,
        ) = self.sensor.sense(
            robot_position=self.robot_position,
            static_obstacles=self.world.static_obstacles,
            dynamic_obstacles=self.dynamic_obstacles,
        )

        self.known_static_obstacles.update(
            visible_static
        )

        self.visible_dynamic_obstacles = (
            visible_dynamic
        )

    def current_blocked_cells(
        self,
    ) -> Set[GridPosition]:

        return (
            self.known_static_obstacles
            | self.visible_dynamic_obstacles
        )

    # =========================================================
    # PATH PLANNING
    # =========================================================

    def replan(
        self,
    ) -> None:

        path = self.planner.plan(
            start=self.robot_position,
            goal=self.goal,
            blocked=self.current_blocked_cells(),
        )

        self.controller.update_path(
            path
        )

        self.replans += 1

        if path:
            self.successful_replans += 1

            self.status_message = (
                f"Path available ({len(path)} nodes)"
            )

        else:
            self.failed_replans += 1

            self.status_message = (
                "No valid route available"
            )

    # =========================================================
    # AUTONOMOUS MOVEMENT
    # =========================================================

    def move_robot(
        self,
    ) -> None:

        if self.goal_reached:
            return

        self.update_dynamic_obstacle()

        self.perform_sensor_scan()

        blocked = self.current_blocked_cells()

        must_replan = (
            not self.controller.has_path()
            or self.controller.path_contains_obstacle(
                blocked
            )
            or (
                self.steps > 0
                and self.steps
                % PERIODIC_REPLAN_STEPS
                == 0
            )
        )

        if must_replan:
            self.replan()

        next_position = (
            self.controller.next_waypoint(
                self.robot_position
            )
        )

        if next_position is None:
            self.replan()

            next_position = (
                self.controller.next_waypoint(
                    self.robot_position
                )
            )

        if next_position is None:
            self.status_message = (
                "Robot waiting for valid route"
            )
            return

        actual_blocked = (
            self.world.static_obstacles
            | self.dynamic_obstacles
        )

        if next_position in actual_blocked:
            self.collisions_prevented += 1

            self.status_message = (
                "Unsafe movement prevented"
            )

            if (
                next_position
                in self.world.static_obstacles
            ):
                self.known_static_obstacles.add(
                    next_position
                )

            self.replan()
            return

        self.robot_position = next_position

        self.steps += 1
        self.total_distance += 1

        self.perform_sensor_scan()

        if self.controller.goal_reached(
            current_position=self.robot_position,
            goal=self.goal,
        ):
            self.goal_reached = True

            self.status_message = (
                "MISSION COMPLETED SUCCESSFULLY"
            )

    # =========================================================
    # DRAWING HELPERS
    # =========================================================

    def draw_text(
        self,
        text: str,
        x: int,
        y: int,
        font,
        color=(35, 35, 35),
    ) -> None:

        surface = font.render(
            text,
            True,
            color,
        )

        self.screen.blit(
            surface,
            (
                x,
                y,
            ),
        )

    def draw_grid(
        self,
    ) -> None:

        for x in range(
            GRID_WIDTH + 1
        ):
            pygame.draw.line(
                self.screen,
                (220, 220, 220),
                (
                    x * CELL_SIZE,
                    0,
                ),
                (
                    x * CELL_SIZE,
                    SCREEN_HEIGHT,
                ),
                1,
            )

        for y in range(
            GRID_HEIGHT + 1
        ):
            pygame.draw.line(
                self.screen,
                (220, 220, 220),
                (
                    0,
                    y * CELL_SIZE,
                ),
                (
                    GRID_WIDTH
                    * CELL_SIZE,
                    y * CELL_SIZE,
                ),
                1,
            )

    def draw_static_obstacles(
        self,
    ) -> None:

        for (
            x,
            y,
        ) in self.world.static_obstacles:

            rectangle = pygame.Rect(
                x * CELL_SIZE,
                y * CELL_SIZE,
                CELL_SIZE,
                CELL_SIZE,
            )

            if (
                x,
                y,
            ) in self.known_static_obstacles:

                color = (
                    55,
                    55,
                    55,
                )

            else:
                color = (
                    190,
                    190,
                    190,
                )

            pygame.draw.rect(
                self.screen,
                color,
                rectangle,
            )

    def draw_dynamic_obstacles(
        self,
    ) -> None:

        for (
            x,
            y,
        ) in self.dynamic_obstacles:

            rectangle = pygame.Rect(
                x * CELL_SIZE,
                y * CELL_SIZE,
                CELL_SIZE,
                CELL_SIZE,
            )

            pygame.draw.rect(
                self.screen,
                (220, 60, 60),
                rectangle,
            )

    def draw_sensor_radius(
        self,
    ) -> None:

        center = (
            self.robot_position[0]
            * CELL_SIZE
            + CELL_SIZE // 2,
            self.robot_position[1]
            * CELL_SIZE
            + CELL_SIZE // 2,
        )

        pygame.draw.circle(
            self.screen,
            (40, 130, 240),
            center,
            SENSOR_RADIUS * CELL_SIZE,
            2,
        )

    def draw_path(
        self,
    ) -> None:

        if not self.controller.path:
            return

        points: List[
            Tuple[int, int]
        ] = []

        for (
            x,
            y,
        ) in self.controller.path:

            points.append(
                (
                    x * CELL_SIZE
                    + CELL_SIZE // 2,
                    y * CELL_SIZE
                    + CELL_SIZE // 2,
                )
            )

        if len(points) >= 2:
            pygame.draw.lines(
                self.screen,
                (40, 165, 255),
                False,
                points,
                4,
            )

    def draw_goal(
        self,
    ) -> None:

        x, y = self.goal

        center = (
            x * CELL_SIZE
            + CELL_SIZE // 2,
            y * CELL_SIZE
            + CELL_SIZE // 2,
        )

        pygame.draw.circle(
            self.screen,
            (255, 180, 0),
            center,
            CELL_SIZE // 3,
        )

    def draw_robot(
        self,
    ) -> None:

        x, y = self.robot_position

        center = (
            x * CELL_SIZE
            + CELL_SIZE // 2,
            y * CELL_SIZE
            + CELL_SIZE // 2,
        )

        pygame.draw.circle(
            self.screen,
            (30, 100, 235),
            center,
            CELL_SIZE // 3,
        )

        pygame.draw.circle(
            self.screen,
            (255, 255, 255),
            center,
            CELL_SIZE // 3,
            2,
        )

    # =========================================================
    # SIDEBAR
    # =========================================================

    def draw_sidebar(
        self,
    ) -> None:

        sidebar_x = (
            GRID_WIDTH
            * CELL_SIZE
        )

        pygame.draw.rect(
            self.screen,
            (247, 247, 247),
            (
                sidebar_x,
                0,
                SIDEBAR_WIDTH,
                SCREEN_HEIGHT,
            ),
        )

        content_x = (
            sidebar_x + 20
        )

        # TITLE
        self.draw_text(
            "AUTONOMOUS NAVIGATION",
            content_x,
            18,
            self.title_font,
        )

        pygame.draw.line(
            self.screen,
            (205, 205, 205),
            (
                content_x,
                52,
            ),
            (
                SCREEN_WIDTH - 20,
                52,
            ),
            1,
        )

        # MISSION
        self.draw_text(
            "MISSION",
            content_x,
            66,
            self.section_font,
        )

        self.draw_text(
            f"Robot position: {self.robot_position}",
            content_x,
            92,
            self.small_font,
        )

        self.draw_text(
            f"Goal position:  {self.goal}",
            content_x,
            113,
            self.small_font,
        )

        # TELEMETRY
        self.draw_text(
            "TELEMETRY",
            content_x,
            145,
            self.section_font,
        )

        telemetry = [
            f"Steps: {self.steps}",
            f"Distance units: {self.total_distance}",
            f"Total replans: {self.replans}",
            f"Successful replans: {self.successful_replans}",
            f"Failed replans: {self.failed_replans}",
            f"Collisions prevented: {self.collisions_prevented}",
            f"Known obstacles: {len(self.known_static_obstacles)}",
            f"Sensor radius: {SENSOR_RADIUS}",
        ]

        y_position = 170

        for item in telemetry:
            self.draw_text(
                item,
                content_x,
                y_position,
                self.small_font,
            )

            y_position += 21

        # LEGEND
        self.draw_text(
            "LEGEND",
            content_x,
            350,
            self.section_font,
        )

        legend = [
            "Blue circle = Robot",
            "Orange = Goal",
            "Red = Dynamic obstacle",
            "Dark gray = Detected wall",
            "Light gray = Unknown wall",
            "Blue line = Planned route",
            "Blue ring = Sensor range",
        ]

        y_position = 375

        for item in legend:
            self.draw_text(
                item,
                content_x,
                y_position,
                self.small_font,
            )

            y_position += 20

        # STATUS BOX
        status_box_y = (
            SCREEN_HEIGHT - 62
        )

        pygame.draw.rect(
            self.screen,
            (235, 235, 235),
            (
                sidebar_x + 12,
                status_box_y,
                SIDEBAR_WIDTH - 24,
                48,
            ),
            border_radius=5,
        )

        self.draw_text(
            "STATUS",
            content_x,
            status_box_y + 5,
            self.section_font,
        )

        status_color = (
            (25, 125, 55)
            if self.goal_reached
            else (40, 70, 120)
        )

        self.draw_text(
            self.status_message[:35],
            content_x,
            status_box_y + 26,
            self.small_font,
            status_color,
        )

    # =========================================================
    # COMPLETE FRAME
    # =========================================================

    def render(
        self,
    ) -> None:

        self.screen.fill(
            (255, 255, 255)
        )

        self.draw_static_obstacles()
        self.draw_path()
        self.draw_sensor_radius()
        self.draw_dynamic_obstacles()
        self.draw_goal()
        self.draw_robot()
        self.draw_grid()
        self.draw_sidebar()

        pygame.display.flip()

    # =========================================================
    # RESULTS
    # =========================================================

    def save_results(
        self,
    ) -> None:

        elapsed_time = (
            time.time()
            - self.start_time
        )

        metrics = {
            "status": (
                "success"
                if self.goal_reached
                else "stopped"
            ),
            "start": START,
            "goal": GOAL,
            "steps": self.steps,
            "total_distance_units": (
                self.total_distance
            ),
            "replans_total": self.replans,
            "successful_replans": (
                self.successful_replans
            ),
            "failed_replans": (
                self.failed_replans
            ),
            "collisions_prevented": (
                self.collisions_prevented
            ),
            "known_static_obstacles": len(
                self.known_static_obstacles
            ),
            "sensor_radius": SENSOR_RADIUS,
            "execution_seconds": round(
                elapsed_time,
                2,
            ),
        }

        metrics_path = os.path.join(
            OUTPUT_DIRECTORY,
            "run_metrics.json",
        )

        with open(
            metrics_path,
            "w",
            encoding="utf-8",
        ) as file:

            json.dump(
                metrics,
                file,
                indent=4,
            )

        screenshot_path = os.path.join(
            OUTPUT_DIRECTORY,
            "final_run.png",
        )

        pygame.image.save(
            self.screen,
            screenshot_path,
        )

        print()
        print("=" * 55)
        print(
            "AUTONOMOUS NAVIGATION RUN COMPLETE"
        )
        print("=" * 55)

        for (
            key,
            value,
        ) in metrics.items():

            print(
                f"{key}: {value}"
            )

        print()

        print(
            f"Metrics saved to: {metrics_path}"
        )

        print(
            f"Screenshot saved to: {screenshot_path}"
        )

    # =========================================================
    # MAIN LOOP
    # =========================================================

    def run(
        self,
    ) -> None:

        running = True

        while running:

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    running = False

                if event.type == pygame.KEYDOWN:

                    if event.key == pygame.K_ESCAPE:
                        running = False

            if (
                not self.goal_reached
                and self.frame_counter
                % MOVE_EVERY_N_FRAMES
                == 0
            ):
                self.move_robot()

            self.render()

            if (
                self.goal_reached
                and not self.results_saved
            ):
                self.render()
                self.save_results()
                self.results_saved = True

            self.frame_counter += 1

            self.clock.tick(
                FPS
            )

        pygame.quit()