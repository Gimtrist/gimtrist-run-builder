"""
Occupancy-grid representation of the simulated environment.

This module creates the virtual world used by the autonomous navigation
system. The world contains boundaries, corridors, walls, and obstacles.
"""

from typing import List, Set, Tuple

import numpy as np


# A grid position is represented as:
# (x, y)
GridPosition = Tuple[int, int]


class GridMap:
    """
    Represents a 2D occupancy-grid environment.

    A cell value of:
    0 = free space
    1 = obstacle
    """

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height

        # NumPy matrix representing the map.
        self.occupancy_grid = np.zeros(
            (height, width),
            dtype=np.uint8,
        )

        # Store obstacle coordinates for quick checking.
        self.static_obstacles: Set[GridPosition] = set()

        # Build the default virtual world.
        self._create_default_environment()

    def _add_obstacle(self, x: int, y: int) -> None:
        """
        Add an obstacle to the environment.

        The obstacle is added to both:
        1. the NumPy occupancy grid
        2. the obstacle-coordinate set
        """

        position = (x, y)

        if self.in_bounds(position):
            self.static_obstacles.add(position)

            self.occupancy_grid[y, x] = 1

    def _create_default_environment(self) -> None:
        """
        Create the obstacle layout used in the simulator.

        The map includes:
        - outer boundaries
        - vertical walls
        - horizontal walls
        - corridor openings
        - small obstacle clusters

        Gaps are intentionally included so that A* can find valid routes.
        """

        # =====================================================
        # OUTER BOUNDARY
        # =====================================================

        # Top and bottom walls
        for x in range(self.width):
            self._add_obstacle(x, 0)
            self._add_obstacle(x, self.height - 1)

        # Left and right walls
        for y in range(self.height):
            self._add_obstacle(0, y)
            self._add_obstacle(self.width - 1, y)

        # =====================================================
        # VERTICAL WALL 1
        # =====================================================

        # Two openings are left in this wall.
        for y in range(2, 17):
            if y not in (6, 13):
                self._add_obstacle(8, y)

        # =====================================================
        # HORIZONTAL WALL
        # =====================================================

        # Two adjacent openings form a wider corridor.
        for x in range(10, 23):
            if x not in (15, 16):
                self._add_obstacle(x, 10)

        # =====================================================
        # VERTICAL WALL 2
        # =====================================================

        for y in range(3, 19):
            if y not in (7, 14):
                self._add_obstacle(23, y)

        # =====================================================
        # SMALL OBSTACLE CLUSTERS
        # =====================================================

        # Upper-middle obstacle
        for x in range(12, 15):
            self._add_obstacle(x, 4)

        # Lower-right obstacle
        for x in range(18, 21):
            self._add_obstacle(x, 16)

        # Lower-left obstacle
        for y in range(12, 15):
            self._add_obstacle(4, y)

    def in_bounds(self, position: GridPosition) -> bool:
        """
        Return True if a grid position is inside the map.
        """

        x, y = position

        return (
            0 <= x < self.width
            and 0 <= y < self.height
        )

    def is_obstacle(self, position: GridPosition) -> bool:
        """
        Return True if a cell contains an obstacle.
        """

        return position in self.static_obstacles

    def is_free(self, position: GridPosition) -> bool:
        """
        Return True if a cell is valid and not occupied.
        """

        return (
            self.in_bounds(position)
            and not self.is_obstacle(position)
        )

    def neighbors(
        self,
        position: GridPosition,
    ) -> List[GridPosition]:
        """
        Return valid four-connected neighboring cells.

        The robot can currently move:
        - right
        - left
        - down
        - up

        Diagonal movement is intentionally disabled for Version 1.
        """

        x, y = position

        candidates = [
            (x + 1, y),
            (x - 1, y),
            (x, y + 1),
            (x, y - 1),
        ]

        valid_neighbors = [
            cell
            for cell in candidates
            if self.is_free(cell)
        ]

        return valid_neighbors

    def obstacle_count(self) -> int:
        """
        Return the total number of static obstacles.
        """

        return len(self.static_obstacles)

    def print_map_summary(self) -> None:
        """
        Print a short summary for testing/debugging.
        """

        print("Grid Map Summary")
        print("----------------")
        print(f"Width: {self.width}")
        print(f"Height: {self.height}")
        print(
            f"Static obstacles: {self.obstacle_count()}"
        )