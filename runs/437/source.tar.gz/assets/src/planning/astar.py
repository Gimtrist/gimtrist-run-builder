"""
A* path-planning algorithm.

This module calculates a collision-free path from the robot's current
position to the goal while avoiding blocked grid cells.
"""

import heapq
from typing import Dict, List, Optional, Set, Tuple


GridPosition = Tuple[int, int]


class AStarPlanner:
    """
    A* planner for a 2D grid.

    The planner uses:
    - four-direction movement
    - Manhattan-distance heuristic
    - uniform movement cost
    """

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height

    @staticmethod
    def heuristic(
        current: GridPosition,
        goal: GridPosition,
    ) -> int:
        """
        Estimate remaining distance using Manhattan distance.

        Formula:
        h = |x1 - x2| + |y1 - y2|
        """

        return (
            abs(current[0] - goal[0])
            + abs(current[1] - goal[1])
        )

    def in_bounds(
        self,
        position: GridPosition,
    ) -> bool:
        """
        Return True if position lies inside the grid.
        """

        x, y = position

        return (
            0 <= x < self.width
            and 0 <= y < self.height
        )

    def get_neighbors(
        self,
        position: GridPosition,
        blocked: Set[GridPosition],
    ) -> List[GridPosition]:
        """
        Return valid neighboring cells that are not blocked.
        """

        x, y = position

        candidates = [
            (x + 1, y),
            (x - 1, y),
            (x, y + 1),
            (x, y - 1),
        ]

        return [
            cell
            for cell in candidates
            if self.in_bounds(cell)
            and cell not in blocked
        ]

    @staticmethod
    def reconstruct_path(
        came_from: Dict[
            GridPosition,
            GridPosition,
        ],
        current: GridPosition,
    ) -> List[GridPosition]:
        """
        Reconstruct the final route from goal back to start.
        """

        path = [current]

        while current in came_from:
            current = came_from[current]
            path.append(current)

        path.reverse()

        return path

    def plan(
        self,
        start: GridPosition,
        goal: GridPosition,
        blocked: Set[GridPosition],
    ) -> Optional[List[GridPosition]]:
        """
        Calculate a path from start to goal.

        Returns:
            List of grid positions if a route exists.
            None if no route exists.
        """

        # Make a copy so the original set is not modified.
        blocked = set(blocked)

        # The robot's current location must always be usable.
        blocked.discard(start)

        # The target must also remain reachable.
        blocked.discard(goal)

        if start == goal:
            return [start]

        # Priority queue.
        # Each item contains:
        # (estimated total cost, path cost so far, position)
        open_heap = []

        heapq.heappush(
            open_heap,
            (
                self.heuristic(start, goal),
                0,
                start,
            ),
        )

        # Stores the best previous node for each visited cell.
        came_from: Dict[
            GridPosition,
            GridPosition,
        ] = {}

        # Cost from start to each cell.
        g_score: Dict[
            GridPosition,
            float,
        ] = {
            start: 0
        }

        visited = set()

        while open_heap:
            (
                _,
                current_cost,
                current,
            ) = heapq.heappop(open_heap)

            # Ignore already processed nodes.
            if current in visited:
                continue

            visited.add(current)

            # Goal reached.
            if current == goal:
                return self.reconstruct_path(
                    came_from,
                    current,
                )

            for neighbor in self.get_neighbors(
                current,
                blocked,
            ):
                # Every grid movement costs 1.
                tentative_cost = (
                    current_cost + 1
                )

                previous_cost = g_score.get(
                    neighbor,
                    float("inf"),
                )

                if tentative_cost < previous_cost:
                    came_from[neighbor] = current
                    g_score[neighbor] = (
                        tentative_cost
                    )

                    estimated_total_cost = (
                        tentative_cost
                        + self.heuristic(
                            neighbor,
                            goal,
                        )
                    )

                    heapq.heappush(
                        open_heap,
                        (
                            estimated_total_cost,
                            tentative_cost,
                            neighbor,
                        ),
                    )

        # No valid path exists.
        return None