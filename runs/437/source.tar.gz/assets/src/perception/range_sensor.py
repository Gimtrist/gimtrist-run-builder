"""
Simulated range-sensor perception module.

This module imitates a simple 2D LiDAR/range sensor by detecting
obstacles that fall within a configurable sensing radius.
"""

from math import sqrt
from typing import Iterable, Set, Tuple


GridPosition = Tuple[int, int]


class RangeSensor:
    """
    Simulated 2D range sensor.

    The sensor detects static and dynamic obstacles located within
    a specified radius around the robot.
    """

    def __init__(self, radius: int = 5):
        self.radius = radius

    @staticmethod
    def distance(
        first: GridPosition,
        second: GridPosition,
    ) -> float:
        """
        Calculate Euclidean distance between two grid positions.

        Formula:
        sqrt((x2 - x1)^2 + (y2 - y1)^2)
        """

        return sqrt(
            (first[0] - second[0]) ** 2
            + (first[1] - second[1]) ** 2
        )

    def is_visible(
        self,
        robot_position: GridPosition,
        obstacle_position: GridPosition,
    ) -> bool:
        """
        Return True if an obstacle lies within sensor range.
        """

        return (
            self.distance(
                robot_position,
                obstacle_position,
            )
            <= self.radius
        )

    def sense(
        self,
        robot_position: GridPosition,
        static_obstacles: Iterable[GridPosition],
        dynamic_obstacles: Iterable[GridPosition],
    ):
        """
        Detect obstacles visible from the robot's current position.

        Returns:
            visible_static:
                static obstacles currently inside sensor radius

            visible_dynamic:
                dynamic obstacles currently inside sensor radius
        """

        visible_static: Set[GridPosition] = {
            obstacle
            for obstacle in static_obstacles
            if self.is_visible(
                robot_position,
                obstacle,
            )
        }

        visible_dynamic: Set[GridPosition] = {
            obstacle
            for obstacle in dynamic_obstacles
            if self.is_visible(
                robot_position,
                obstacle,
            )
        }

        return (
            visible_static,
            visible_dynamic,
        )