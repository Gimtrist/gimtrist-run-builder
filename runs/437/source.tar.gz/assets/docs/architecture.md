# System Architecture

## AI-Based Autonomous Navigation System

This document explains the software architecture of the virtual autonomous-navigation system implemented in this repository.

The project follows a modular architecture inspired by the perception-planning-control pipeline used in autonomous mobile robots and intelligent navigation systems.

The current version runs entirely inside a virtual 2D environment and does not require physical robotics hardware.

---

# 1. High-Level Architecture

```text
Virtual Environment
        │
        ▼
Simulated Range Sensor
        │
        ▼
Obstacle Perception
        │
        ▼
Environment Knowledge
        │
        ▼
A* Path Planner
        │
        ▼
Navigation Controller
        │
        ▼
Collision Validation
        │
   ┌────┴────┐
   │         │
 CLEAR     BLOCKED
   │         │
   ▼         ▼
 MOVE      REPLAN
   │         │
   └────┬────┘
        ▼
   Feedback Loop
        │
        ▼
Visualization + Metrics