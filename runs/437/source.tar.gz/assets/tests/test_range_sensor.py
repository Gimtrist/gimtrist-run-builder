"""
Tests for simulated range perception.
"""

from src.perception.range_sensor import RangeSensor


def test_sensor_detects_nearby_static_obstacles():
    sensor = RangeSensor(radius=5)

    static_obstacles = {
        (3, 4),
        (6, 5),
        (10, 10),
    }

    visible_static, _ = sensor.sense(
        robot_position=(5, 5),
        static_obstacles=static_obstacles,
        dynamic_obstacles=set(),
    )

    assert (3, 4) in visible_static
    assert (6, 5) in visible_static
    assert (10, 10) not in visible_static


def test_sensor_detects_dynamic_obstacle():
    sensor = RangeSensor(radius=5)

    dynamic_obstacles = {
        (2, 2),
        (20, 20),
    }

    _, visible_dynamic = sensor.sense(
        robot_position=(5, 5),
        static_obstacles=set(),
        dynamic_obstacles=dynamic_obstacles,
    )

    assert (2, 2) in visible_dynamic
    assert (20, 20) not in visible_dynamic


def test_sensor_boundary_distance():
    sensor = RangeSensor(radius=5)

    obstacle = {
        (8, 9)
    }

    visible_static, _ = sensor.sense(
        robot_position=(5, 5),
        static_obstacles=obstacle,
        dynamic_obstacles=set(),
    )

    assert (8, 9) in visible_static