"""
Unit tests for the A* path planner.

These tests verify that the planner:
1. finds a normal route
2. avoids obstacles
3. handles start = goal
4. reports failure when no route exists
"""

from src.planning.astar import AStarPlanner


def test_astar_finds_simple_path():
    planner = AStarPlanner(
        width=10,
        height=10,
    )

    start = (1, 1)
    goal = (8, 8)

    path = planner.plan(
        start=start,
        goal=goal,
        blocked=set(),
    )

    assert path is not None
    assert path[0] == start
    assert path[-1] == goal


def test_astar_avoids_obstacle():
    planner = AStarPlanner(
        width=10,
        height=10,
    )

    start = (1, 1)
    goal = (5, 1)

    blocked = {
        (2, 1),
        (3, 1),
        (4, 1),
    }

    path = planner.plan(
        start=start,
        goal=goal,
        blocked=blocked,
    )

    assert path is not None

    for position in path:
        assert position not in blocked


def test_start_equals_goal():
    planner = AStarPlanner(
        width=5,
        height=5,
    )

    path = planner.plan(
        start=(2, 2),
        goal=(2, 2),
        blocked=set(),
    )

    assert path == [(2, 2)]


def test_no_path_available():
    planner = AStarPlanner(
        width=5,
        height=5,
    )

    start = (2, 2)
    goal = (4, 4)

    blocked = {
        (1, 2),
        (3, 2),
        (2, 1),
        (2, 3),
    }

    path = planner.plan(
        start=start,
        goal=goal,
        blocked=blocked,
    )

    assert path is None