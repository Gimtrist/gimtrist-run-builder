"""
Unit tests for the navigation controller.
"""

from src.navigation.controller import NavigationController


def test_controller_stores_path():
    controller = NavigationController()

    path = [
        (1, 1),
        (2, 1),
        (3, 1),
    ]

    controller.update_path(path)

    assert controller.path == path


def test_controller_returns_next_waypoint():
    controller = NavigationController()

    controller.update_path(
        [
            (1, 1),
            (2, 1),
            (3, 1),
        ]
    )

    next_position = controller.next_waypoint(
        (1, 1)
    )

    assert next_position == (2, 1)


def test_controller_detects_blocked_path():
    controller = NavigationController()

    controller.update_path(
        [
            (1, 1),
            (2, 1),
            (3, 1),
            (4, 1),
        ]
    )

    blocked = {
        (3, 1)
    }

    assert controller.path_contains_obstacle(
        blocked
    )


def test_controller_path_is_clear():
    controller = NavigationController()

    controller.update_path(
        [
            (1, 1),
            (2, 1),
            (3, 1),
        ]
    )

    blocked = {
        (5, 5)
    }

    assert not controller.path_contains_obstacle(
        blocked
    )


def test_goal_reached():
    controller = NavigationController()

    assert controller.goal_reached(
        current_position=(8, 8),
        goal=(8, 8),
    )


def test_goal_not_reached():
    controller = NavigationController()

    assert not controller.goal_reached(
        current_position=(7, 8),
        goal=(8, 8),
    )