# 弹弹小球闯关 · Bounce Ball Adventure

> 一个用纯 Python + Pygame 实现的 2D 物理休闲闯关小游戏，并附带零依赖的 HTML5 网页版，可在线试玩。

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Play Online](https://img.shields.io/badge/Play%20Online-GitHub%20Pages-brightgreen.svg)](https://Zhoushijiehqu.github.io/bounce-ball-game/)

🎮 **在线试玩（GitHub Pages）**：<https://Zhoushijiehqu.github.io/bounce-ball-game/>

---

## 简介

操控一颗白色小球，在 8 个手工设计的关卡中滚动、跳跃、躲避尖刺、收集金色星星，最终滚进绿色终点圈。
游戏包含弹簧、尖刺、减速粘液、加速板、移动平台、传送门等机关，还有「重力反转」彩蛋。

项目同时提供两种实现：

| 版本 | 技术栈 | 运行方式 | 依赖 |
| --- | --- | --- | --- |
| 桌面版 | Python + Pygame | `python main.py` | pygame |
| 网页版 | 原生 Canvas + JavaScript | 浏览器打开 `web/index.html` | 无（零依赖） |

网页版在桌面版基础上做了工程重构：定步长物理（60Hz，跨刷新率一致）、网格化碰撞、土狼时间/按键缓冲/可变跳跃高度等手感优化，并加入了粒子、屏幕震动、拖尾等表现增强。

---

## 特性

- 🎯 **8 个手工关卡**，难度循序渐进，全部可达、可满星
- 🌟 星星收集系统（追求满星）
- 🌀 多种机关：弹簧、尖刺、减速粘液、加速板、移动平台、成对传送门
- 🔄 重力反转彩蛋（按 `G`）
- 💀 生命系统（10 条命）与关卡重置
- 📱 网页版自带触屏控制，移动端可玩
- 🔊 网页版纯合成音效（WebAudio，无外部资源）
- 🧪 桌面版自带无头冒烟测试（`smoke_test.py`）

---

## 操作说明

### 桌面版（Pygame）

| 按键 | 功能 |
| --- | --- |
| `←` / `→` | 左右施加力矩（惯性滑行，模拟球体滚动） |
| `Space` | 跳跃（仅着地时） |
| `G` | 重力反转（吸向天花板） |
| `R` | 本关重置 |
| `Enter` | 菜单 / 通关画面中开始或继续 |
| `Esc` | 返回菜单 |

### 网页版（浏览器）

- 移动：`←` `→` 或 `A` `D`
- 跳跃：`Space`
- 反转重力：`G`，重开：`R`，暂停：`P`，音效开关：`M`
- 移动端：屏幕左下/右下虚拟按键

---

## 安装与运行

### 桌面版

需要 Python 3.10+ 与 Pygame。建议使用虚拟环境：

```bash
# 1. 创建并激活虚拟环境
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. 安装依赖
pip install -r requirements.txt

# 3. 启动游戏
python main.py
```

### 网页版

**方式一：直接打开**

双击 `web/index.html` 用浏览器打开即可（无需任何构建步骤）。

**方式二：本地起一个静态服务器（推荐，避免个别浏览器对 file:// 的限制）**

```bash
cd web
python3 -m http.server 8000
# 浏览器访问 http://localhost:8000
```

**方式三：在线试玩**

访问 <https://Zhoushijiehqu.github.io/bounce-ball-game/>

---

## 测试

桌面版提供无头冒烟测试（使用 SDL 哑驱动，无需图形界面）：

```bash
pip install -r requirements.txt
python smoke_test.py
```

测试覆盖：8 个关卡的关卡数据合法性、每关 300 帧物理模拟不崩溃、传送门成对、全部关卡及状态画面渲染不抛异常。

网页版附带关卡校验工具（需 Node.js）：

```bash
node web/tools/check-levels.js
```

用于检查关卡字符串的行列尺寸、出生点/终点/传送门是否齐全。

---

## 目录结构

```
bounce-ball-game/
├── main.py                 # 桌面版（Pygame）游戏主程序，含 8 关关卡数据
├── smoke_test.py           # 桌面版无头冒烟测试
├── requirements.txt        # 桌面版依赖
├── LICENSE                 # MIT 许可证
└── web/                    # 网页版（零依赖）
    ├── index.html          # 入口页面
    ├── css/style.css       # 样式
    ├── js/
    │   ├── game.js         # 游戏引擎（Canvas + 定步长物理）
    │   ├── levels.js       # 关卡数据（与桌面版一致）
    │   └── audio.js        # WebAudio 合成音效
    └── tools/
        └── check-levels.js # 关卡校验工具
```

---

## 关卡编辑

两个版本的关卡数据共用同一套字符映射（25 列 × 18 行，每个 tile 32px）：

| 字符 | 含义 | 字符 | 含义 |
| --- | --- | --- | --- |
| `#` | 墙 | `.` | 空 |
| `P` | 出生点 | `E` | 终点 |
| `S` | 弹簧 | `^` | 尖刺 |
| `*` | 星星 | `M` | 移动平台 |
| `~` | 减速粘液 | `>` | 加速板（向右） |
| `A` / `B` | 传送门对 |  |  |

修改 `main.py` 中的 `LEVELS` 列表（桌面版）或 `web/js/levels.js`（网页版），然后用对应的校验工具验证可达性与满星。

---

## 开源协议

本项目基于 [MIT License](LICENSE) 开源，可自由使用、修改与再发布，只需保留版权声明。
