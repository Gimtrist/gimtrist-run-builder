# -*- coding: utf-8 -*-
"""
弹弹小球闯关 (Bounce Ball Adventure)
纯 Python + Pygame 实现的 2D 休闲物理闯关小游戏。

操作：
    ← / →   左右施加力矩（惯性滑行，模拟球体滚动）
    Space   跳跃（仅着地时）
    G       重力反转（彩蛋：吸向天花板）
    R       本关重置
    Enter   菜单/通关画面中开始或继续
    Esc     返回菜单

目标：操控小球滚进绿色终点圆圈，逐关递进，收集金色星星追求满星。
"""

import os
import sys
import random
import math

import pygame
from pygame.locals import (
    QUIT, KEYDOWN, KEYUP, K_LEFT, K_RIGHT, K_SPACE, K_r, K_g,
    K_RETURN, K_ESCAPE,
)

# ---------------------------------------------------------------------------
# 基础常量
# ---------------------------------------------------------------------------
TILE = 32
COLUMNS = 25
ROWS = 18
PLAY_W = COLUMNS * TILE          # 800
PLAY_H = ROWS * TILE             # 576
UI_H = 24                        # 顶部状态栏高度
WINDOW_W = PLAY_W
WINDOW_H = PLAY_H + UI_H         # 600

FPS = 60

# 颜色（深色背景 + 明亮机关）
COLOR_BG = (26, 26, 46)          # #1a1a2e
COLOR_UI = (16, 16, 32)
COLOR_WALL = (74, 78, 105)       # #4a4e69
COLOR_WALL_EDGE = (90, 94, 125)
COLOR_BALL = (255, 255, 255)
COLOR_BALL_GLOW = (120, 200, 255)
COLOR_SPRING = (6, 214, 160)     # #06d6a0
COLOR_SPIKE = (239, 71, 111)     # #ef476f
COLOR_GOAL = (6, 214, 160)
COLOR_STAR = (255, 209, 102)     # #ffd166
COLOR_MOVING = (17, 138, 178)    # #118ab2
COLOR_SLIME = (123, 44, 191)     # #7b2cbf
COLOR_SPEED = (0, 180, 216)      # #00b4d8
COLOR_PORTAL = (155, 93, 229)
COLOR_TEXT = (230, 230, 245)

# 物理参数
GRAVITY = 0.5
JUMP_VY = -12                    # 原为 -11（最大跳高仅 121px），多处台阶不可达
MOVE_ACC = 0.5
MAX_VX = 8
BOOST_VX = MAX_VX + 4            # 加速板期间的速度上限
BOOST_STEPS = 30
FRICTION = 0.98
WALL_BOUNCE = 0.7
SETTLE_VY = 1.5                  # 反弹速度低于该值视为停稳（避免落地微颤）
BALL_R = 10

START_LIVES = 10

# Tile 字符映射
#  '#' 墙  'P' 出生  'E' 终点  'S' 弹簧  '^' 尖刺  '*' 星星
#  'M' 移动平台  '~' 减速粘液  '>' 加速板(向右)  'A'/'B' 传送门
CHAR_WALL = '#'
CHAR_SPAWN = 'P'
CHAR_GOAL = 'E'
CHAR_SPRING = 'S'
CHAR_SPIKE = '^'
CHAR_STAR = '*'
CHAR_MOVING = 'M'
CHAR_SLIME = '~'
CHAR_SPEED = '>'
CHAR_PORTAL_A = 'A'
CHAR_PORTAL_B = 'B'
CHAR_EMPTY = '.'


# ---------------------------------------------------------------------------
# 关卡数据：每个字符串块为一关，行宽 = COLUMNS，行数 = ROWS
# ---------------------------------------------------------------------------
LEVELS = [
    # ---------- 第 1 关 ----------
    """
#########################
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#............*..........#
#...........####........#
#.......................#
#......*................#
#.....####..............#
#.......................#
#.......................#
#P.........*..........E.#
#########################
""",
    # ---------- 第 2 关 ----------
    """
#########################
#.......................#
#.......................#
#.......................#
#.................*.....#
#.......................#
#.......................#
#....*.......E..........#
#...........#####.......#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#P...S.................*#
#########################
""",
    # ---------- 第 3 关 ----------
    """
#########################
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.............*.........#
#............####.......#
#.......................#
#......*................#
#.......####............#
#.......................#
#.......................#
#...####................#
#.......................#
#.......................#
#P........^^^..*....E...#
#########################
""",
    # ---------- 第 4 关 ----------
    """
#########################
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#...........*...........#
#..........#####........#
#.......................#
#.......................#
#.....M............*....#
#.......................#
#.......................#
#..#####.........M......#
#.......................#
#.......................#
#P.................E...*#
#########################
""",
    # ---------- 第 5 关 ----------
    """
#########################
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.......................#
#.....................*.#
#.......................#
#.......................#
#.......................#
#.................*..E..#
#................#####..#
#.......................#
#.......................#
#P.*.~~~~~.>..^^^.......#
#########################
""",
    # ---------- 第 6 关 ----------
    """
#########################
#.......................#
#.......................#
#.......................#
#.......................#
#...................*...#
#....................E..#
#.....#####....M...####.#
#.......................#
#.......................#
#.......................#
#....*..................#
#.......................#
#.......................#
#.......................#
#.......................#
#P..S...^^^..^^^^......*#
#########################
""",
    # ---------- 第 7 关 ----------
    """
#########################
#...........#...........#
#...........#...........#
#..........*#...........#
#...........#...........#
#...........#...........#
#..........A#...........#
#.........####..........#
#...........#...........#
#......*....#...........#
#.....###...#...........#
#...........#...........#
#..###......#...........#
#...........#....B......#
#...........#...###.....#
#...........#...........#
#P..........#......*.E..#
#########################
""",
    # ---------- 第 8 关 ----------
    """
#########################
#.......................#
#..*....................#
#.###...................#
#.......................#
#...................*...#
#....................E..#
#.###....M.....M...####.#
#.......................#
#.......................#
#.###...................#
#.......................#
#.......................#
#.###...................#
#.......................#
#.......................#
#P~~~..^^^...^^..^^..*..#
#########################
""",
]


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------
def parse_level(raw):
    """把多行字符串解析为结构化关卡数据。"""
    rows = [r for r in raw.split('\n')]
    # 取宽度一致的行
    grid = []
    for r in rows:
        if r == '':
            continue
        # 截断/补齐到 COLUMNS
        line = list(r.ljust(COLUMNS, CHAR_EMPTY)[:COLUMNS])
        grid.append(line)
    # 保证行数为 ROWS
    while len(grid) < ROWS:
        grid.append([CHAR_EMPTY] * COLUMNS)
    grid = grid[:ROWS]

    spawn = (TILE, TILE)  # 默认
    stars = []
    springs = []
    spikes = []
    slimes = []
    speeds = []
    goal = None
    portals = {'A': None, 'B': None}
    moving = []

    for ry, row in enumerate(grid):
        for rx, ch in enumerate(row):
            x = rx * TILE
            y = ry * TILE
            if ch == CHAR_SPAWN:
                spawn = (x + TILE // 2, y + TILE // 2)
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_GOAL:
                goal = (x + TILE // 2, y + TILE // 2)
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_STAR:
                stars.append([x + TILE // 2, y + TILE // 2, True])
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_SPRING:
                springs.append(pygame.Rect(x, y + TILE - 10, TILE, 10))
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_SPIKE:
                spikes.append(pygame.Rect(x + 4, y + TILE - 14, TILE - 8, 14))
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_SLIME:
                slimes.append(pygame.Rect(x, y + TILE - 8, TILE, 8))
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_SPEED:
                speeds.append(pygame.Rect(x, y + TILE - 8, TILE, 8))
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_MOVING:
                moving.append({'x': x, 'y': y, 'base_x': x,
                               'w': TILE, 'h': TILE // 2,
                               'dir': 1, 'range': TILE * 2, 'speed': 1.2,
                               'dx': 0,
                               'rect': pygame.Rect(x, y, TILE, TILE // 2)})
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_PORTAL_A:
                portals['A'] = (x + TILE // 2, y + TILE // 2)
                row[rx] = CHAR_EMPTY
            elif ch == CHAR_PORTAL_B:
                portals['B'] = (x + TILE // 2, y + TILE // 2)
                row[rx] = CHAR_EMPTY

    # ---- 边界保险：强制四周为墙，防止小球飞出/漏球 ----
    for ry in range(ROWS):
        grid[ry][0] = CHAR_WALL
        grid[ry][COLUMNS - 1] = CHAR_WALL
    grid[0] = [CHAR_WALL] * COLUMNS
    grid[ROWS - 1] = [CHAR_WALL] * COLUMNS

    walls = []
    for ry, row in enumerate(grid):
        for rx, ch in enumerate(row):
            if ch == CHAR_WALL:
                walls.append(pygame.Rect(rx * TILE, ry * TILE, TILE, TILE))

    return {
        'grid': grid,
        'walls': walls,
        'spawn': spawn,
        'goal': goal,
        'stars': stars,
        'springs': springs,
        'spikes': spikes,
        'slimes': slimes,
        'speeds': speeds,
        'moving': moving,
        'portals': portals,
    }


# ---------------------------------------------------------------------------
# 小球
# ---------------------------------------------------------------------------
class Ball:
    def __init__(self, x, y):
        self.reset(x, y)

    def reset(self, x, y):
        self.x = x
        self.y = y
        self.vx = 0
        self.vy = 0
        self.on_ground = False
        self.dead = False
        self.boost = 0
        self.ground_plat = None

    def rect(self):
        return pygame.Rect(self.x - BALL_R, self.y - BALL_R,
                           BALL_R * 2, BALL_R * 2)


# ---------------------------------------------------------------------------
# 游戏主体
# ---------------------------------------------------------------------------
class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_W, WINDOW_H))
        pygame.display.set_caption('弹弹小球闯关')
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('menlo,consolas,monospace', 18)
        self.big_font = pygame.font.SysFont('menlo,consolas,monospace', 40, bold=True)
        self.state = 'MENU'            # MENU / PLAYING / LEVEL_DONE / GAME_OVER / ALL_DONE
        self.level_index = 0
        self.lives = START_LIVES
        self.total_stars = 0
        self.collected_stars = 0
        self.level_star_count = 0
        self.gravity_dir = 1           # 1 向下，-1 向上（重力反转）
        self.portal_cooldown = 0
        self.level_data = None
        self.ball = None
        self.bg_stars = self._make_bg_stars()

    # ---- 背景星点装饰 ----
    def _make_bg_stars(self):
        return [[random.randint(0, WINDOW_W), random.randint(0, WINDOW_H),
                 random.randint(1, 2)] for _ in range(60)]

    # ---- 关卡加载 ----
    def load_level(self, idx):
        self.level_index = idx
        self.level_data = parse_level(LEVELS[idx])
        self.ball = Ball(*self.level_data['spawn'])
        # 统计本关星星数
        self.level_star_count = len(self.level_data['stars'])
        self.collected_stars = 0
        self.portal_cooldown = 0
        self.gravity_dir = 1
        self.state = 'PLAYING'

    def restart_level(self):
        # 重置当前关（保留已收集的星星状态 -> 重新计数）
        self.load_level(self.level_index)

    def lose_life(self):
        self.lives -= 1
        if self.lives <= 0:
            self.state = 'GAME_OVER'
        else:
            self.restart_level()

    # ---- 物理与碰撞 ----
    def handle_input(self):
        keys = pygame.key.get_pressed()
        if self.state != 'PLAYING':
            return
        b = self.ball
        if keys[K_LEFT]:
            b.vx -= MOVE_ACC
        if keys[K_RIGHT]:
            b.vx += MOVE_ACC
        if keys[K_SPACE] and b.on_ground:
            b.vy = JUMP_VY * self.gravity_dir
            b.on_ground = False
        cap = BOOST_VX if b.boost > 0 else MAX_VX
        if b.boost > 0:
            b.boost -= 1
        b.vx = max(-cap, min(cap, b.vx))

    def update_moving_platforms(self):
        for m in self.level_data['moving']:
            old_x = m['x']
            m['x'] += m['dir'] * m['speed']
            if m['x'] > m['base_x'] + m['range']:
                m['x'] = m['base_x'] + m['range']
                m['dir'] = -1
            elif m['x'] < m['base_x'] - m['range']:
                m['x'] = m['base_x'] - m['range']
                m['dir'] = 1
            m['dx'] = m['x'] - old_x
            m['rect'] = pygame.Rect(m['x'], m['y'], m['w'], m['h'])
            # 站在平台上的小球随平台一起移动
            if self.ball.ground_plat is m:
                self.ball.x += m['dx']

    def _land(self, b, top, bottom, plat=None):
        """沿 y 轴碰撞后的统一处理：按重力方向判定是否算着地。"""
        if b.vy > 0:
            b.y = top - BALL_R
            if self.gravity_dir == 1:
                b.on_ground = True
                if plat is not None:
                    b.ground_plat = plat
        elif b.vy < 0:
            b.y = bottom + BALL_R
            if self.gravity_dir == -1:
                b.on_ground = True
                if plat is not None:
                    b.ground_plat = plat
        else:
            return
        b.vy = -b.vy * WALL_BOUNCE
        if abs(b.vy) < SETTLE_VY:
            b.vy = 0

    def collide_tile_axis(self, axis):
        """分轴处理与墙壁/移动平台的 AABB 碰撞并反弹。"""
        b = self.ball
        r = b.rect()
        # 墙壁
        for w in self.level_data['walls']:
            if r.colliderect(w):
                if axis == 'x':
                    if b.vx > 0:
                        b.x = w.left - BALL_R
                    elif b.vx < 0:
                        b.x = w.right + BALL_R
                    else:
                        continue
                    b.vx = -b.vx * WALL_BOUNCE
                else:
                    self._land(b, w.top, w.bottom)
                r = b.rect()
        # 移动平台
        for m in self.level_data.get('moving', []):
            mr = m.get('rect')
            if mr and r.colliderect(mr):
                if axis == 'x':
                    if b.vx > 0:
                        b.x = mr.left - BALL_R
                    elif b.vx < 0:
                        b.x = mr.right + BALL_R
                    else:
                        continue
                    b.vx = -b.vx * WALL_BOUNCE
                else:
                    self._land(b, mr.top, mr.bottom, plat=m)
                r = b.rect()

    def check_triggers(self):
        b = self.ball
        r = b.rect()
        # 弹簧
        for s in self.level_data['springs']:
            if r.colliderect(s) and b.vy >= 0:
                b.vy = -18 * self.gravity_dir
                b.on_ground = False
        # 尖刺 -> 死亡
        for sp in self.level_data['spikes']:
            if r.colliderect(sp):
                b.dead = True
        # 减速粘液
        for sl in self.level_data['slimes']:
            if r.colliderect(sl):
                b.vx *= 0.85
        # 加速板（向右冲刺，一段时间内提高速度上限）
        for spd in self.level_data['speeds']:
            if r.colliderect(spd):
                if b.boost <= 0:
                    b.boost = BOOST_STEPS
                b.vx = min(b.vx + 1.2, BOOST_VX)
        # 星星收集
        for star in self.level_data['stars']:
            if star[2]:
                sx, sy = star[0], star[1]
                if (b.x - sx) ** 2 + (b.y - sy) ** 2 < (BALL_R + 10) ** 2:
                    star[2] = False
                    self.collected_stars += 1
                    self.total_stars += 1
        # 传送门
        if self.portal_cooldown <= 0:
            pa = self.level_data['portals']['A']
            pb = self.level_data['portals']['B']
            if pa and pb:
                if (b.x - pa[0]) ** 2 + (b.y - pa[1]) ** 2 < 18 ** 2:
                    b.x, b.y = pb
                    self.portal_cooldown = 30
                elif (b.x - pb[0]) ** 2 + (b.y - pb[1]) ** 2 < 18 ** 2:
                    b.x, b.y = pa
                    self.portal_cooldown = 30
        else:
            self.portal_cooldown -= 1
        # 终点
        if self.level_data['goal']:
            gx, gy = self.level_data['goal']
            if (b.x - gx) ** 2 + (b.y - gy) ** 2 < (BALL_R + 14) ** 2:
                self.state = 'LEVEL_DONE'
        # 掉出深渊
        if b.y > PLAY_H + 40 or b.y < -40:
            b.dead = True
        if b.dead:
            self.lose_life()
            b.dead = False

    def update(self):
        if self.state != 'PLAYING':
            return
        # 平台先走一步（带动上一帧站在上面的球），再做球体物理
        self.update_moving_platforms()
        self.ball.ground_plat = None
        self.handle_input()
        b = self.ball
        b.on_ground = False
        b.vy += GRAVITY * self.gravity_dir
        b.vx *= FRICTION
        # 分轴移动 + 碰撞
        b.x += b.vx
        self.collide_tile_axis('x')
        b.y += b.vy
        self.collide_tile_axis('y')
        self.check_triggers()

    # ---- 渲染 ----
    def draw_background(self):
        self.screen.fill(COLOR_BG)
        for s in self.bg_stars:
            self.screen.fill((60, 60, 90), (s[0], s[1], s[2], s[2]))

    def draw_ui(self):
        pygame.draw.rect(self.screen, COLOR_UI, (0, 0, WINDOW_W, UI_H))
        txt = self.font.render(
            f'关卡 {self.level_index + 1}/{len(LEVELS)}   生命 {self.lives}   '
            f'星星 {self.collected_stars}/{self.level_star_count}   总星 {self.total_stars}',
            True, COLOR_TEXT)
        self.screen.blit(txt, (8, 3))

    def draw_level(self):
        ld = self.level_data
        # 墙
        for w in ld['walls']:
            pygame.draw.rect(self.screen, COLOR_WALL, w)
            pygame.draw.rect(self.screen, COLOR_WALL_EDGE,
                             (w.left, w.top, w.w, 3))
        # 弹簧
        for s in ld['springs']:
            pygame.draw.rect(self.screen, COLOR_SPRING, s)
            pygame.draw.line(self.screen, (255, 255, 255),
                             (s.centerx, s.top), (s.centerx, s.top - 8), 2)
        # 尖刺
        for sp in ld['spikes']:
            pts = [(sp.left, sp.bottom), (sp.centerx, sp.top),
                   (sp.right, sp.bottom)]
            pygame.draw.polygon(self.screen, COLOR_SPIKE, pts)
        # 粘液
        for sl in ld['slimes']:
            pygame.draw.rect(self.screen, COLOR_SLIME, sl)
        # 加速板
        for spd in ld['speeds']:
            pygame.draw.rect(self.screen, COLOR_SPEED, spd)
            pygame.draw.polygon(self.screen, (255, 255, 255),
                                [(spd.right - 2, spd.centery),
                                 (spd.right - 10, spd.top + 2),
                                 (spd.right - 10, spd.bottom - 2)])
        # 移动平台
        for m in ld['moving']:
            mr = m.get('rect')
            if mr:
                pygame.draw.rect(self.screen, COLOR_MOVING, mr)
        # 传送门
        pa = ld['portals']['A']
        pb = ld['portals']['B']
        t = pygame.time.get_ticks() // 200
        if pa:
            self._draw_portal(pa, t)
        if pb:
            self._draw_portal(pb, t + 3)
        # 星星
        for star in ld['stars']:
            if star[2]:
                self._draw_star(star[0], star[1])
        # 终点（脉冲圆）
        if ld['goal']:
            gx, gy = ld['goal']
            pulse = 14 + int(3 * (1 + math.sin(
                pygame.time.get_ticks() / 200)))
            pygame.draw.circle(self.screen, COLOR_GOAL, (gx, gy), pulse, 3)
            pygame.draw.circle(self.screen, (6, 214, 160, 80), (gx, gy), pulse // 2)
        # 小球
        b = self.ball
        glow = pygame.Surface((BALL_R * 4, BALL_R * 4), pygame.SRCALPHA)
        pygame.draw.circle(glow, COLOR_BALL_GLOW, (BALL_R * 2, BALL_R * 2),
                           BALL_R * 1.8)
        self.screen.blit(glow, (b.x - BALL_R * 2, b.y - BALL_R * 2))
        pygame.draw.circle(self.screen, COLOR_BALL, (b.x, b.y), BALL_R)
        # 高光
        pygame.draw.circle(self.screen, (200, 230, 255),
                           (b.x - 3, b.y - 3), 3)

    def _draw_portal(self, pos, phase):
        x, y = pos
        for i in range(3):
            r = 6 + i * 4 + (phase % 4)
            pygame.draw.circle(self.screen, COLOR_PORTAL, (x, y), r, 2)

    def _draw_star(self, x, y):
        pts = []
        for i in range(5):
            a = -90 + i * 72
            ra = math.radians(a)
            pts.append((x + 9 * math.cos(ra), y + 9 * math.sin(ra)))
            a2 = a + 36
            ra2 = math.radians(a2)
            pts.append((x + 4 * math.cos(ra2), y + 4 * math.sin(ra2)))
        pygame.draw.polygon(self.screen, COLOR_STAR, pts)

    def draw_overlay(self, title, subtitle):
        overlay = pygame.Surface((WINDOW_W, WINDOW_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        t1 = self.big_font.render(title, True, COLOR_TEXT)
        t2 = self.font.render(subtitle, True, (200, 200, 220))
        self.screen.blit(t1, (WINDOW_W // 2 - t1.get_width() // 2,
                              WINDOW_H // 2 - 40))
        self.screen.blit(t2, (WINDOW_W // 2 - t2.get_width() // 2,
                              WINDOW_H // 2 + 10))

    def render(self):
        self.draw_background()
        if self.state in ('PLAYING', 'LEVEL_DONE', 'GAME_OVER', 'ALL_DONE'):
            if self.level_data:
                self.draw_level()
            self.draw_ui()
        if self.state == 'MENU':
            self.draw_overlay('弹弹小球闯关', '按 Enter 开始  |  ←→ 控制  Space 跳  G 重力反转')
        elif self.state == 'LEVEL_DONE':
            self.draw_overlay('关卡通过！',
                              f'本关星星 {self.collected_stars}/{self.level_star_count}  按 Enter 进入下一关')
        elif self.state == 'GAME_OVER':
            self.draw_overlay('游戏结束', '按 Enter 返回菜单重新开始')
        elif self.state == 'ALL_DONE':
            self.draw_overlay('全部通关！', f'收集星星总计 {self.total_stars}  按 Enter 返回菜单')
        pygame.display.flip()

    # ---- 事件 ----
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                return False
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    self.state = 'MENU'
                if self.state == 'MENU' and event.key == K_RETURN:
                    self.lives = START_LIVES
                    self.total_stars = 0
                    self.load_level(0)
                elif self.state == 'LEVEL_DONE' and event.key == K_RETURN:
                    if self.level_index + 1 < len(LEVELS):
                        self.load_level(self.level_index + 1)
                    else:
                        self.state = 'ALL_DONE'
                elif self.state == 'GAME_OVER' and event.key == K_RETURN:
                    self.state = 'MENU'
                elif self.state == 'ALL_DONE' and event.key == K_RETURN:
                    self.state = 'MENU'
                elif self.state == 'PLAYING':
                    if event.key == K_r:
                        self.restart_level()
                    if event.key == K_g:
                        self.gravity_dir *= -1
        return True

    def run(self):
        running = True
        while running:
            running = self.handle_events()
            self.update()
            self.render()
            self.clock.tick(FPS)
        pygame.quit()


def main():
    game = Game()
    game.run()


if __name__ == '__main__':
    main()
