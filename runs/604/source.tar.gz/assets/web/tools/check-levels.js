#!/usr/bin/env node
/* 关卡数据校验：尺寸、边界、出生点/终点唯一、传送门配对、机关不越界。 */
"use strict";
const fs = require("fs");
const path = require("path");

const src = fs.readFileSync(path.join(__dirname, "..", "js", "levels.js"), "utf8");
const raws = [...src.matchAll(/`([^`]*)`/g)].map(m => m[1]);

const NAMES = [...src.matchAll(/"([^"]+)",\s*$/gm)].map(m => m[1]);
const COLS = 25, ROWS = 18;
const OBJECTS = "PES*^~>ABM";

let fail = 0;
console.log(`共 ${raws.length} 关\n`);

raws.forEach((raw, i) => {
  const rows = raw.replace(/\r/g, "").split("\n").filter(r => r.length > 0);
  const problems = [];
  if (rows.length !== ROWS) problems.push(`行数 ${rows.length} ≠ ${ROWS}`);
  rows.forEach((r, ri) => {
    if (r.length !== COLS) problems.push(`第 ${ri + 1} 行宽 ${r.length} ≠ ${COLS}`);
  });
  const grid = rows.map(r => r.split(""));
  // 边界
  if (rows.length === ROWS) {
    if (!grid[0].every(c => c === "#")) problems.push("顶行非全墙");
    if (!grid[ROWS - 1].every(c => c === "#")) problems.push("底行非全墙");
    grid.forEach((r, ri) => {
      if (r[0] !== "#") problems.push(`第 ${ri + 1} 行左边界缺墙`);
      if (r[COLS - 1] !== "#") problems.push(`第 ${ri + 1} 行右边界缺墙`);
    });
  }
  const count = ch => grid.flat().filter(c => c === ch).length;
  const nP = count("P"), nE = count("E"), nA = count("A"), nB = count("B");
  if (nP !== 1) problems.push(`出生点 P ×${nP}`);
  if (nE !== 1) problems.push(`终点 E ×${nE}`);
  if ((nA > 0) !== (nB > 0)) problems.push("传送门未配对");
  // 机关不应贴在边界行/列上（会被强制墙覆盖）
  grid.forEach((r, ri) => r.forEach((c, ci) => {
    if (OBJECTS.includes(c) && (ri === 0 || ri === ROWS - 1 || ci === 0 || ci === COLS - 1)) {
      problems.push(`机关 '${c}' 位于边界 (${ci},${ri})`);
    }
  }));
  // 出生点下方应可站立（P 正下方 3 格内应有墙）
  const stats = {};
  grid.flat().forEach(c => { if (OBJECTS.includes(c)) stats[c] = (stats[c] || 0) + 1; });

  const name = NAMES[i] || `第${i + 1}关`;
  if (problems.length) {
    fail++;
    console.log(`✗ 第 ${i + 1} 关 [${name}]`);
    problems.forEach(p => console.log(`    - ${p}`));
  } else {
    const s = Object.entries(stats).map(([k, v]) => k + v).join(" ");
    console.log(`✓ 第 ${i + 1} 关 [${name}]  ${s}`);
  }
});

console.log(fail ? `\n${fail} 关存在问题 ✗` : "\n全部关卡校验通过 ✅");
process.exit(fail ? 1 : 0);
