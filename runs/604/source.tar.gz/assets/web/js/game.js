/* -*- coding: utf-8 -*-
 * 弹弹小球闯关 · Web 版引擎
 * 原生 Canvas + 定步长物理（60Hz），不依赖任何库。
 *
 * 相比 pygame 原版的优化：
 *  - 定步长物理：任意刷新率（60/120Hz）下速度一致
 *  - 网格化碰撞：按 tile 查表，不再遍历全部墙块
 *  - 平台手感：土狼时间、按键缓冲、长按连跳、可变跳跃高度
 *  - 修复重力反转后无法起跳、加速板被速度上限吞掉的问题
 *  - 移动平台会正确带动站在上面的小球
 *  - 静态图层缓存、粒子系统、屏幕震动、拖尾等表现增强
 */
"use strict";

(() => {

// ---------------------------------------------------------------------------
// 常量
// ---------------------------------------------------------------------------
const TILE = 32, COLS = 25, ROWS = 18;
const W = COLS * TILE, H = ROWS * TILE;      // 800 x 576 逻辑分辨率

const STEP_MS = 1000 / 60;
const GRAVITY = 0.5;
const JUMP_VY = 12;                           // 原版 11 时跳高仅 121px，多处台阶不可达
const MOVE_ACC = 0.5;
const MAX_VX = 8;
const BOOST_VX = MAX_VX + 4;                  // 加速板期间的速度上限
const BOOST_STEPS = 30;
const FRICTION = 0.98;
const WALL_BOUNCE = 0.7;
const SETTLE_VY = 1.5;                        // 反弹速度低于该值时视为停稳
const BALL_R = 10;
const SPRING_VY = 18;
const COYOTE = 6;                             // 土狼时间（步）
const START_LIVES = 10;

const C = {
  bg0: "#232348", bg1: "#1a1a2e",
  wall: "#4a4e69", wallTop: "#6b7099", wallSide: "#3f4260", wallBottom: "#343752",
  ball: "#ffffff", ballGlow: "rgba(120,200,255,", ballHi: "#cfeaff",
  spring: "#06d6a0", springDark: "#04976f",
  spike: "#ef476f", spikeDark: "#b32b4e",
  goal: "#06d6a0",
  star: "#ffd166",
  moving: "#118ab2", movingTop: "#3fc1e0",
  slime: "#7b2cbf", slimeLite: "#9d5cd0",
  speed: "#00b4d8",
  portal: "#9b5de5", portal2: "#c77dff",
  text: "#e8e8f5",
};

const STORE_PROGRESS = "bb.progress";
const STORE_MUTE = "bb.muted";

// ---------------------------------------------------------------------------
// 关卡解析
// ---------------------------------------------------------------------------
function parseLevel(raw) {
  const lines = raw.replace(/\r/g, "").split("\n").filter(l => l.length > 0);
  const grid = [];
  for (let r = 0; r < ROWS; r++) {
    const line = (lines[r] || "").padEnd(COLS, ".").slice(0, COLS);
    grid.push(line.split(""));
  }
  // 边界保险：四周强制为墙
  for (let r = 0; r < ROWS; r++) { grid[r][0] = "#"; grid[r][COLS - 1] = "#"; }
  grid[0] = Array(COLS).fill("#");
  grid[ROWS - 1] = Array(COLS).fill("#");

  const ld = {
    grid,
    spawn: { x: TILE + TILE / 2, y: TILE + TILE / 2 },
    goal: null,
    stars: [], springs: [], spikes: [], slimes: [], speeds: [], moving: [],
    portals: { A: null, B: null },
  };

  for (let ry = 0; ry < ROWS; ry++) {
    for (let rx = 0; rx < COLS; rx++) {
      const ch = grid[ry][rx];
      const x = rx * TILE, y = ry * TILE;
      switch (ch) {
        case "P":
          ld.spawn = { x: x + TILE / 2, y: y + TILE / 2 };
          grid[ry][rx] = ".";
          break;
        case "E":
          ld.goal = { x: x + TILE / 2, y: y + TILE / 2 };
          grid[ry][rx] = ".";
          break;
        case "*":
          ld.stars.push({ x: x + TILE / 2, y: y + TILE / 2, taken: false, phase: rx + ry });
          grid[ry][rx] = ".";
          break;
        case "S":
          ld.springs.push({ x: x, y: y + TILE - 10, w: TILE, h: 10, squash: 0 });
          grid[ry][rx] = ".";
          break;
        case "^":
          ld.spikes.push({ x: x + 4, y: y + TILE - 14, w: TILE - 8, h: 14 });
          grid[ry][rx] = ".";
          break;
        case "~":
          ld.slimes.push({ x: x, y: y + TILE - 8, w: TILE, h: 8 });
          grid[ry][rx] = ".";
          break;
        case ">":
          ld.speeds.push({ x: x, y: y + TILE - 8, w: TILE, h: 8 });
          grid[ry][rx] = ".";
          break;
        case "M":
          ld.moving.push({
            baseX: x, x: x, y: y, w: TILE, h: TILE / 2,
            dir: 1, range: TILE * 2, speed: 1.2, dx: 0,
          });
          grid[ry][rx] = ".";
          break;
        case "A": ld.portals.A = { x: x + TILE / 2, y: y + TILE / 2 }; grid[ry][rx] = "."; break;
        case "B": ld.portals.B = { x: x + TILE / 2, y: y + TILE / 2 }; grid[ry][rx] = "."; break;
      }
    }
  }
  return ld;
}

// ---------------------------------------------------------------------------
// 进度存档
// ---------------------------------------------------------------------------
function loadProgress() {
  try {
    const p = JSON.parse(localStorage.getItem(STORE_PROGRESS));
    if (p && p.unlocked >= 1) return { unlocked: p.unlocked, best: p.best || {} };
  } catch (e) { /* ignore */ }
  return { unlocked: 1, best: {} };
}
function saveProgress(p) {
  try { localStorage.setItem(STORE_PROGRESS, JSON.stringify(p)); } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------------------
// 游戏主体
// ---------------------------------------------------------------------------
class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");

    this.state = "MENU";          // MENU / PLAYING / PAUSED / LEVEL_DONE / GAME_OVER / ALL_DONE
    this.levelIndex = 0;
    this.ld = null;
    this.lives = START_LIVES;
    this.collected = 0;
    this.totalStars = 0;
    this.progress = loadProgress();

    this.gravityDir = 1;
    this.portalCd = 0;
    this.flipCd = 0;
    this.time = 0;

    this.dying = false;
    this.dieTimer = 0;
    this.shake = 0;

    this.ball = { x: 0, y: 0, vx: 0, vy: 0, grounded: false, coyote: 0,
                  jumpLock: false, boost: 0, groundPlat: null, roll: 0 };
    this.input = { left: false, right: false, jumpHeld: false };

    this.particles = [];
    this.trail = [];
    this.floatTexts = [];

    this.bgDots = [];
    for (let i = 0; i < 70; i++) {
      this.bgDots.push({ x: Math.random() * W, y: Math.random() * H,
                         s: Math.random() * 1.6 + 0.4, ph: Math.random() * Math.PI * 2 });
    }

    this.staticLayer = document.createElement("canvas");
    this.resize();
  }

  // ---- 视口 ----
  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    const w = Math.max(1, Math.round(rect.width * dpr));
    const h = Math.max(1, Math.round(rect.height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
      this.rebuildStatic();
    }
  }

  rebuildStatic() {
    const dpr = this.canvas.width / W;
    this.staticLayer.width = this.canvas.width;
    this.staticLayer.height = this.canvas.height;
    const sctx = this.staticLayer.getContext("2d");
    sctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    sctx.clearRect(0, 0, W, H);
    if (!this.ld) return;
    this.drawWalls(sctx);
    this.drawSpikes(sctx);
    this.drawSlimes(sctx);
    this.drawSpeeds(sctx);
  }

  // ---- 关卡 ----
  loadLevel(idx) {
    this.levelIndex = idx;
    this.ld = parseLevel(LEVELS[idx]);
    this.collected = 0;
    this.gravityDir = 1;
    this.portalCd = 0;
    this.flipCd = 0;
    this.dying = false;
    this.dieTimer = 0;
    this.particles.length = 0;
    this.trail.length = 0;
    this.floatTexts.length = 0;
    this.resetBall();
    this.state = "PLAYING";
    this.rebuildStatic();
    updateHud();
  }

  resetBall() {
    const b = this.ball;
    b.x = this.ld.spawn.x;
    b.y = this.ld.spawn.y;
    b.vx = 0; b.vy = 0;
    b.grounded = false; b.coyote = 0; b.jumpLock = false;
    b.boost = 0; b.groundPlat = null; b.roll = 0;
    this.trail.length = 0;
  }

  loseLife() {
    this.lives--;
    updateHud();
    if (this.lives <= 0) {
      this.state = "GAME_OVER";
      showOverlay("ov-gameover");
    } else {
      this.loadLevel(this.levelIndex);   // 与原版一致：重来本关，星星重置
    }
  }

  // ---- 物理步进 ----
  step() {
    this.time++;
    if (this.shake > 0) this.shake--;
    this.updateParticles();
    this.updateFloatTexts();

    if (this.state !== "PLAYING") return;

    if (this.dying) {
      this.dieTimer--;
      if (this.dieTimer <= 0) this.loseLife();
      return;
    }

    const b = this.ball;
    const ld = this.ld;

    // 1) 移动平台先走一步，并带动上一帧站在上面的球
    this.updateMoving();
    if (b.groundPlat) b.x += b.groundPlat.dx;
    b.groundPlat = null;

    // 2) 输入
    if (this.input.left) b.vx -= MOVE_ACC;
    if (this.input.right) b.vx += MOVE_ACC;
    const capVx = b.boost > 0 ? BOOST_VX : MAX_VX;
    if (b.boost > 0) b.boost--;
    b.vx = Math.max(-capVx, Math.min(capVx, b.vx));
    // 起跳（土狼时间 + 长按连跳）
    if (this.input.jumpHeld && !b.jumpLock && (b.grounded || b.coyote > 0)) {
      b.vy = -JUMP_VY * this.gravityDir;
      b.jumpLock = true;
      b.grounded = false;
      b.coyote = 0;
      sfx.play("jump");
      this.dust(b.x, b.y + BALL_R * this.gravityDir, 4);
    }
    if (b.grounded) b.coyote = COYOTE;
    else if (b.coyote > 0) b.coyote--;

    // 3) 重力 / 摩擦
    b.vy += GRAVITY * this.gravityDir;
    b.vy = Math.max(-16, Math.min(16, b.vy));
    b.vx *= FRICTION;

    // 4) 分轴移动 + 碰撞
    b.grounded = false;
    b.x += b.vx;
    this.collideTiles("x");
    this.collidePlatforms("x");
    b.y += b.vy;
    const impact = b.vy;
    this.collideTiles("y");
    this.collidePlatforms("y");
    if (b.grounded && Math.abs(impact) > 4) {
      sfx.play("land");
      this.dust(b.x, b.y + BALL_R * this.gravityDir, 5);
    }
    b.roll += b.vx * 0.06;

    // 5) 拖尾
    if (Math.abs(b.vx) + Math.abs(b.vy) > 1.6) {
      this.trail.push({ x: b.x, y: b.y });
      if (this.trail.length > 12) this.trail.shift();
    } else if (this.trail.length) {
      this.trail.shift();
    }

    // 6) 触发器
    this.checkTriggers();

    if (this.portalCd > 0) this.portalCd--;
    if (this.flipCd > 0) this.flipCd--;
  }

  solidAt(tx, ty) {
    if (tx < 0 || tx >= COLS || ty < 0 || ty >= ROWS) return true;
    return this.ld.grid[ty][tx] === "#";
  }

  collideTiles(axis) {
    const b = this.ball, R = BALL_R, T = TILE;
    for (let ty = Math.floor((b.y - R) / T); ty <= Math.floor((b.y + R - 0.01) / T); ty++) {
      for (let tx = Math.floor((b.x - R) / T); tx <= Math.floor((b.x + R - 0.01) / T); tx++) {
        if (!this.solidAt(tx, ty)) continue;
        const x0 = tx * T, y0 = ty * T, x1 = x0 + T, y1 = y0 + T;
        if (b.x + R <= x0 || b.x - R >= x1 || b.y + R <= y0 || b.y - R >= y1) continue;
        this.resolveHit(axis, x0, y0, x1, y1, null);
      }
    }
  }

  collidePlatforms(axis) {
    const b = this.ball, R = BALL_R;
    for (const m of this.ld.moving) {
      const x0 = m.x, y0 = m.y, x1 = m.x + m.w, y1 = m.y + m.h;
      if (b.x + R <= x0 || b.x - R >= x1 || b.y + R <= y0 || b.y - R >= y1) continue;
      this.resolveHit(axis, x0, y0, x1, y1, m);
    }
  }

  resolveHit(axis, x0, y0, x1, y1, plat) {
    const b = this.ball, R = BALL_R;
    if (axis === "x") {
      if (b.vx > 0) b.x = x0 - R;
      else if (b.vx < 0) b.x = x1 + R;
      else b.x = (b.x < (x0 + x1) / 2) ? x0 - R : x1 + R;
      b.vx = -b.vx * WALL_BOUNCE;
      return;
    }
    if (b.vy > 0) {
      b.y = y0 - R;
      if (this.gravityDir === 1) { b.grounded = true; if (plat) b.groundPlat = plat; }
    } else if (b.vy < 0) {
      b.y = y1 + R;
      if (this.gravityDir === -1) { b.grounded = true; if (plat) b.groundPlat = plat; }
    } else return;
    b.vy = -b.vy * WALL_BOUNCE;
    if (Math.abs(b.vy) < SETTLE_VY) b.vy = 0;
  }

  updateMoving() {
    for (const m of this.ld.moving) {
      const oldX = m.x;
      m.x += m.dir * m.speed;
      if (m.x > m.baseX + m.range) { m.x = m.baseX + m.range; m.dir = -1; }
      else if (m.x < m.baseX - m.range) { m.x = m.baseX - m.range; m.dir = 1; }
      m.dx = m.x - oldX;
    }
  }

  checkTriggers() {
    const b = this.ball, ld = this.ld;

    // 弹簧（朝向弹簧面运动时触发）
    for (const s of ld.springs) {
      if (hits(b, s) && b.vy * this.gravityDir >= 0) {
        b.vy = -SPRING_VY * this.gravityDir;
        b.grounded = false;
        s.squash = 1;
        sfx.play("spring");
        this.burst(s.x + s.w / 2, s.y, C.spring, 8, -this.gravityDir);
      }
    }
    // 尖刺
    if (ld.spikes.some(sp => hits(b, sp))) {
      this.die();
      return;
    }
    // 粘液
    for (const sl of ld.slimes) {
      if (hits(b, sl)) b.vx *= 0.85;
    }
    // 加速板
    for (const sd of ld.speeds) {
      if (hits(b, sd)) {
        if (b.boost <= 0) {
          b.boost = BOOST_STEPS;
          sfx.play("portal");
          this.burst(b.x, b.y, C.speed, 6, 0);
        }
        b.vx = Math.min(b.vx + 1.2, BOOST_VX);
      }
    }
    // 星星
    for (const st of ld.stars) {
      if (!st.taken) {
        const dx = b.x - st.x, dy = b.y - st.y;
        if (dx * dx + dy * dy < (BALL_R + 10) * (BALL_R + 10)) {
          st.taken = true;
          this.collected++;
          this.totalStars++;
          updateHud();
          sfx.play("star");
          this.burst(st.x, st.y, C.star, 10, 0);
        }
      }
    }
    // 传送门
    if (this.portalCd <= 0 && ld.portals.A && ld.portals.B) {
      const pa = ld.portals.A, pb = ld.portals.B;
      let from = null, to = null;
      if (dist2(b.x, b.y, pa.x, pa.y) < 18 * 18) { from = pa; to = pb; }
      else if (dist2(b.x, b.y, pb.x, pb.y) < 18 * 18) { from = pb; to = pa; }
      if (from) {
        this.burst(from.x, from.y, C.portal, 8, 0);
        b.x = to.x; b.y = to.y;
        this.portalCd = 30;
        sfx.play("portal");
        this.burst(to.x, to.y, C.portal2, 8, 0);
      }
    }
    // 终点
    if (ld.goal) {
      const dx = b.x - ld.goal.x, dy = b.y - ld.goal.y;
      if (dx * dx + dy * dy < (BALL_R + 14) * (BALL_R + 14)) {
        this.winLevel();
        return;
      }
    }
    // 掉出世界
    if (b.y > H + 60 || b.y < -60) this.die();
  }

  winLevel() {
    const idx = this.levelIndex;
    this.progress.unlocked = Math.max(this.progress.unlocked, Math.min(idx + 2, LEVELS.length));
    this.progress.best[idx] = Math.max(this.progress.best[idx] || 0, this.collected);
    saveProgress(this.progress);
    this.state = "LEVEL_DONE";
    sfx.play("win");
    this.burst(this.ld.goal.x, this.ld.goal.y, C.goal, 26, -1);
    this.burst(this.ld.goal.x, this.ld.goal.y, C.star, 14, -1);
    // 结算面板
    const last = idx === LEVELS.length - 1;
    document.getElementById("done-stars").textContent =
      `第 ${idx + 1} 关 · ${LEVEL_NAMES[idx]} —— 本关星星 ★ ${this.collected}/${this.ld.stars.length}`;
    document.getElementById("done-total").textContent =
      `本次冒险总星 ${this.totalStars} · 下一关已解锁`;
    document.getElementById("btn-next").textContent = last ? "查看结算 🎉" : "下一关 →";
    showOverlay("ov-done");
  }

  die() {
    if (this.dying) return;
    this.dying = true;
    this.dieTimer = 40;
    this.shake = 16;
    sfx.play("death");
    this.burst(this.ball.x, this.ball.y, "#ffffff", 16, 0);
    this.burst(this.ball.x, this.ball.y, C.spike, 12, 0);
  }

  flipGravity() {
    if (this.state !== "PLAYING" || this.dying || this.flipCd > 0) return;
    this.gravityDir *= -1;
    this.flipCd = 24;
    this.ball.grounded = false;
    this.ball.coyote = 0;
    sfx.play("flip");
    this.addText(this.ball.x, this.ball.y - 26, this.gravityDir === -1 ? "重力反转 ↑" : "重力恢复 ↓");
    this.burst(this.ball.x, this.ball.y, "#ffffff", 8, 0);
  }

  // ---- 粒子 / 漂浮文字 ----
  burst(x, y, color, n, dirY) {
    for (let i = 0; i < n; i++) {
      if (this.particles.length > 300) break;
      const a = Math.random() * Math.PI * 2;
      const sp = Math.random() * 3 + 1;
      this.particles.push({
        x, y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp + (dirY || 0) * 1.5,
        life: 1, decay: Math.random() * 0.03 + 0.025,
        size: Math.random() * 3 + 1.5,
        color, grav: 0.08,
      });
    }
  }

  dust(x, y, n) {
    for (let i = 0; i < n; i++) {
      if (this.particles.length > 300) break;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 10, y,
        vx: (Math.random() - 0.5) * 1.6, vy: (Math.random() - 0.5) * 0.8 - this.gravityDir * 0.6,
        life: 0.7, decay: 0.05, size: Math.random() * 2.5 + 1,
        color: "rgba(200,200,230,0.8)", grav: 0.02,
      });
    }
  }

  updateParticles() {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx; p.y += p.vy;
      p.vy += p.grav * this.gravityDir;
      p.life -= p.decay;
      if (p.life <= 0) this.particles.splice(i, 1);
    }
  }

  addText(x, y, text) {
    this.floatTexts.push({ x, y, text, life: 1 });
  }

  updateFloatTexts() {
    for (let i = this.floatTexts.length - 1; i >= 0; i--) {
      const t = this.floatTexts[i];
      t.y -= 0.7;
      t.life -= 0.02;
      if (t.life <= 0) this.floatTexts.splice(i, 1);
    }
  }

  // ---------------------------------------------------------------------------
  // 渲染
  // ---------------------------------------------------------------------------
  render() {
    const ctx = this.ctx;
    const sx = this.canvas.width / W, sy = this.canvas.height / H;
    ctx.setTransform(sx, 0, 0, sy, 0, 0);

    // 屏幕震动
    if (this.shake > 0) {
      const m = this.shake / 16 * 5;
      ctx.translate((Math.random() - 0.5) * m, (Math.random() - 0.5) * m);
    }

    // 背景
    if (!this.bgGrad) {
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, C.bg0);
      g.addColorStop(1, C.bg1);
      this.bgGrad = g;
    }
    ctx.fillStyle = this.bgGrad;
    ctx.fillRect(-8, -8, W + 16, H + 16);
    ctx.fillStyle = "#3c3c60";
    for (const d of this.bgDots) {
      const tw = 0.5 + 0.5 * Math.sin(this.time * 0.03 + d.ph);
      ctx.globalAlpha = 0.25 + tw * 0.5;
      ctx.fillRect(d.x, d.y, d.s, d.s);
    }
    ctx.globalAlpha = 1;

    if (!this.ld) return;

    // 静态图层（墙 / 尖刺 / 粘液 / 加速板）
    ctx.drawImage(this.staticLayer, 0, 0, W, H);

    this.drawSprings(ctx);
    this.drawMoving(ctx);
    this.drawPortals(ctx);
    this.drawStars(ctx);
    this.drawGoal(ctx);
    this.drawParticles(ctx);
    if (!this.dying && this.state !== "GAME_OVER") this.drawBall(ctx);
    this.drawFloatTexts(ctx);
  }

  drawWalls(ctx) {
    const grid = this.ld.grid;
    for (let ty = 0; ty < ROWS; ty++) {
      for (let tx = 0; tx < COLS; tx++) {
        if (grid[ty][tx] !== "#") continue;
        const x = tx * TILE, y = ty * TILE;
        ctx.fillStyle = C.wall;
        ctx.fillRect(x, y, TILE, TILE);
        const openAbove = ty > 0 && grid[ty - 1][tx] !== "#";
        const openBelow = ty < ROWS - 1 && grid[ty + 1][tx] !== "#";
        const openLeft = tx > 0 && grid[ty][tx - 1] !== "#";
        const openRight = tx < COLS - 1 && grid[ty][tx + 1] !== "#";
        if (openAbove) { ctx.fillStyle = C.wallTop; ctx.fillRect(x, y, TILE, 3); }
        if (openBelow) { ctx.fillStyle = C.wallBottom; ctx.fillRect(x, y + TILE - 3, TILE, 3); }
        if (openLeft) { ctx.fillStyle = C.wallSide; ctx.fillRect(x, y, 2, TILE); }
        if (openRight) { ctx.fillStyle = C.wallSide; ctx.fillRect(x + TILE - 2, y, 2, TILE); }
      }
    }
  }

  drawSpikes(ctx) {
    for (const sp of this.ld.spikes) {
      const n = 2, w = sp.w / n;
      for (let i = 0; i < n; i++) {
        const bx = sp.x + i * w;
        ctx.fillStyle = C.spike;
        ctx.beginPath();
        ctx.moveTo(bx, sp.y + sp.h);
        ctx.lineTo(bx + w / 2, sp.y);
        ctx.lineTo(bx + w, sp.y + sp.h);
        ctx.closePath();
        ctx.fill();
      }
      ctx.fillStyle = C.spikeDark;
      ctx.fillRect(sp.x, sp.y + sp.h - 3, sp.w, 3);
    }
  }

  drawSlimes(ctx) {
    for (const sl of this.ld.slimes) {
      const wob = Math.sin(this.time * 0.08 + sl.x * 0.1) * 1.2;
      ctx.fillStyle = C.slime;
      ctx.beginPath();
      ctx.roundRect(sl.x, sl.y + 1 + wob * 0.4, sl.w, sl.h - 1, 4);
      ctx.fill();
      ctx.fillStyle = C.slimeLite;
      ctx.beginPath();
      ctx.roundRect(sl.x + 3, sl.y + 2 + wob * 0.4, sl.w - 6, 2.5, 2);
      ctx.fill();
    }
  }

  drawSpeeds(ctx) {
    for (const sd of this.ld.speeds) {
      ctx.fillStyle = "rgba(0,180,216,0.35)";
      ctx.fillRect(sd.x, sd.y, sd.w, sd.h);
      ctx.save();
      ctx.beginPath();
      ctx.rect(sd.x, sd.y, sd.w, sd.h);
      ctx.clip();
      ctx.strokeStyle = C.speed;
      ctx.lineWidth = 2.5;
      const off = (this.time * 1.2) % 14;
      for (let i = -1; i < 3; i++) {
        const cx = sd.x + 4 + i * 14 + off;
        ctx.beginPath();
        ctx.moveTo(cx, sd.y + 1.5);
        ctx.lineTo(cx + 5, sd.y + sd.h / 2);
        ctx.lineTo(cx, sd.y + sd.h - 1.5);
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  drawSprings(ctx) {
    for (const s of this.ld.springs) {
      if (s.squash > 0.02) s.squash *= 0.9; else s.squash = 0;
      const press = s.squash * 5;
      // 底座
      ctx.fillStyle = C.springDark;
      ctx.fillRect(s.x + 3, s.y + s.h - 3, s.w - 6, 3);
      // 弹簧圈
      ctx.strokeStyle = C.spring;
      ctx.lineWidth = 2;
      ctx.beginPath();
      const top = s.y + press;
      const bot = s.y + s.h - 3;
      ctx.moveTo(s.x + 6, bot);
      for (let i = 0; i < 3; i++) {
        const yy = bot - ((bot - top) / 3) * (i + 0.5);
        ctx.lineTo(i % 2 === 0 ? s.x + s.w - 8 : s.x + 8, yy);
      }
      ctx.lineTo(s.x + s.w / 2, top + 2);
      ctx.stroke();
      // 顶板
      ctx.fillStyle = C.spring;
      ctx.fillRect(s.x + 2, top, s.w - 4, 3.5);
    }
  }

  drawMoving(ctx) {
    for (const m of this.ld.moving) {
      ctx.fillStyle = C.moving;
      ctx.beginPath();
      ctx.roundRect(m.x, m.y, m.w, m.h, 5);
      ctx.fill();
      ctx.fillStyle = C.movingTop;
      ctx.beginPath();
      ctx.roundRect(m.x + 2, m.y + 2, m.w - 4, 3, 2);
      ctx.fill();
      // 方向指示点
      ctx.fillStyle = "rgba(255,255,255,0.75)";
      const cx = m.x + m.w / 2 + m.dir * 8;
      ctx.beginPath();
      ctx.arc(cx, m.y + m.h / 2 + 2, 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  drawPortals(ctx) {
    const ld = this.ld;
    if (ld.portals.A) this.drawPortal(ctx, ld.portals.A, 0);
    if (ld.portals.B) this.drawPortal(ctx, ld.portals.B, 2.2);
  }

  drawPortal(ctx, p, phase) {
    const t = this.time * 0.05 + phase;
    const grad = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, 18);
    grad.addColorStop(0, "rgba(155,93,229,0.55)");
    grad.addColorStop(1, "rgba(155,93,229,0)");
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(p.x, p.y, 18, 0, Math.PI * 2); ctx.fill();
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = i % 2 ? C.portal2 : C.portal;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 6 + i * 4, t * (i % 2 ? -1 : 1) + i, t * (i % 2 ? -1 : 1) + i + 4.2);
      ctx.stroke();
    }
  }

  drawStars(ctx) {
    for (const st of this.ld.stars) {
      if (st.taken) continue;
      const rot = this.time * 0.02 + st.phase;
      const grad = ctx.createRadialGradient(st.x, st.y, 1, st.x, st.y, 14);
      grad.addColorStop(0, "rgba(255,209,102,0.5)");
      grad.addColorStop(1, "rgba(255,209,102,0)");
      ctx.fillStyle = grad;
      ctx.beginPath(); ctx.arc(st.x, st.y, 14, 0, Math.PI * 2); ctx.fill();
      starPath(ctx, st.x, st.y, 9, 4, rot);
      ctx.fillStyle = C.star;
      ctx.fill();
    }
  }

  drawGoal(ctx) {
    const gl = this.ld.goal;
    if (!gl) return;
    const pulse = 14 + 3 * Math.sin(this.time * 0.09);
    const grad = ctx.createRadialGradient(gl.x, gl.y, 2, gl.x, gl.y, pulse);
    grad.addColorStop(0, "rgba(6,214,160,0.55)");
    grad.addColorStop(1, "rgba(6,214,160,0)");
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(gl.x, gl.y, pulse, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = C.goal;
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(gl.x, gl.y, pulse, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeStyle = "rgba(6,214,160,0.6)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 6]);
    ctx.lineDashOffset = -this.time * 0.4;
    ctx.beginPath(); ctx.arc(gl.x, gl.y, pulse + 5, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = C.goal;
    ctx.beginPath(); ctx.arc(gl.x, gl.y, 4.5, 0, Math.PI * 2); ctx.fill();
  }

  drawBall(ctx) {
    const b = this.ball;
    // 拖尾
    for (let i = 0; i < this.trail.length; i++) {
      const t = this.trail[i];
      const k = (i + 1) / this.trail.length;
      ctx.globalAlpha = k * 0.25;
      ctx.fillStyle = C.ballGlow + "1)";
      ctx.beginPath();
      ctx.arc(t.x, t.y, BALL_R * k * 0.8, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    // 光晕
    const speed = Math.abs(b.vx) + Math.abs(b.vy);
    const glowR = BALL_R * 1.8 + Math.min(speed, 14) * 0.4;
    const grad = ctx.createRadialGradient(b.x, b.y, 2, b.x, b.y, glowR);
    grad.addColorStop(0, C.ballGlow + "0.5)");
    grad.addColorStop(1, C.ballGlow + "0)");
    ctx.fillStyle = grad;
    ctx.beginPath(); ctx.arc(b.x, b.y, glowR, 0, Math.PI * 2); ctx.fill();
    // 本体
    const body = ctx.createRadialGradient(b.x - 3, b.y - 4, 1, b.x, b.y, BALL_R);
    body.addColorStop(0, "#ffffff");
    body.addColorStop(1, "#c9d6e8");
    ctx.fillStyle = body;
    ctx.beginPath(); ctx.arc(b.x, b.y, BALL_R, 0, Math.PI * 2); ctx.fill();
    // 滚动纹（两点绕转，体现滚动）
    ctx.fillStyle = "rgba(90,120,160,0.8)";
    for (const da of [0, Math.PI]) {
      const a = b.roll + da;
      ctx.beginPath();
      ctx.arc(b.x + Math.cos(a) * 5, b.y + Math.sin(a) * 5, 1.8, 0, Math.PI * 2);
      ctx.fill();
    }
    // 高光
    ctx.fillStyle = C.ballHi;
    ctx.beginPath(); ctx.arc(b.x - 3.5, b.y - 4, 2.5, 0, Math.PI * 2); ctx.fill();
  }

  drawParticles(ctx) {
    for (const p of this.particles) {
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  drawFloatTexts(ctx) {
    ctx.font = "bold 15px 'PingFang SC', system-ui, sans-serif";
    ctx.textAlign = "center";
    for (const t of this.floatTexts) {
      ctx.globalAlpha = Math.max(0, t.life);
      ctx.fillStyle = "#ffffff";
      ctx.fillText(t.text, t.x, t.y);
    }
    ctx.globalAlpha = 1;
    ctx.textAlign = "left";
  }
}

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------
function dist2(x0, y0, x1, y1) {
  const dx = x0 - x1, dy = y0 - y1;
  return dx * dx + dy * dy;
}

/** 球（半径 BALL_R 的圆的包围盒）与矩形是否重叠 */
function hits(b, r) {
  return b.x + BALL_R > r.x && b.x - BALL_R < r.x + r.w &&
         b.y + BALL_R > r.y && b.y - BALL_R < r.y + r.h;
}

/** 松开跳跃键：解锁连跳 + 可变跳跃高度（提前松开截断上升） */
function cutJump() {
  game.input.jumpHeld = false;
  const b = game.ball;
  b.jumpLock = false;
  if (game.gravityDir === 1 && b.vy < -5) b.vy = -5;
  if (game.gravityDir === -1 && b.vy > 5) b.vy = 5;
}

function starPath(ctx, cx, cy, outer, inner, rot) {
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = rot - Math.PI / 2 + i * Math.PI / 5;
    const r = i % 2 === 0 ? outer : inner;
    const x = cx + Math.cos(a) * r, y = cy + Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

// ---------------------------------------------------------------------------
// DOM / 输入 / 主循环
// ---------------------------------------------------------------------------
const canvas = document.getElementById("game");
const game = new Game(canvas);
const ovIds = ["ov-menu", "ov-pause", "ov-done", "ov-gameover", "ov-alldone"];

function showOverlay(id) {
  for (const oid of ovIds) {
    document.getElementById(oid).classList.toggle("show", oid === id);
  }
}

function updateHud() {
  document.getElementById("hud-level").textContent = `关卡 ${game.levelIndex + 1}/${LEVELS.length}`;
  document.getElementById("hud-lives").textContent = `❤ ×${game.lives}`;
  document.getElementById("hud-stars").textContent =
    `★ ${game.collected}/${game.ld ? game.ld.stars.length : 0}`;
  document.getElementById("hud-total").textContent = `总★ ${game.totalStars}`;
}

function updateSoundIcon() {
  document.getElementById("btn-sound").textContent = sfx.muted ? "🔇" : "🔊";
}

function refreshMenu() {
  const grid = document.getElementById("level-grid");
  grid.innerHTML = "";
  LEVELS.forEach((_, i) => {
    const btn = document.createElement("button");
    btn.className = "level-cell";
    btn.disabled = i + 1 > game.progress.unlocked;
    btn.title = LEVEL_NAMES[i];
    const stars = game.progress.best[i];
    btn.innerHTML = `${i + 1}<span class="lv-stars">${btn.disabled ? "🔒" : "★" + (stars || 0)}</span>`;
    btn.addEventListener("click", () => { sfx.ensure(); sfx.play("click"); startAt(i); });
    grid.appendChild(btn);
  });
  const best = Object.values(game.progress.best).reduce((a, b) => a + b, 0);
  document.getElementById("best-line").textContent = `最佳纪录：总★ ${best} / ${LEVELS.length * 3}`;
}

function startAt(idx) {
  game.lives = START_LIVES;
  game.totalStars = 0;
  game.loadLevel(idx);
  showOverlay(null);
  document.getElementById("hud").classList.remove("hidden");
}

function backToMenu() {
  game.state = "MENU";
  showOverlay("ov-menu");
  document.getElementById("hud").classList.add("hidden");
  refreshMenu();
}

function togglePause() {
  if (game.state === "PLAYING") {
    game.state = "PAUSED";
    showOverlay("ov-pause");
  } else if (game.state === "PAUSED") {
    game.state = "PLAYING";
    showOverlay(null);
  }
}

// ---- 按钮 ----
function on(id, fn) {
  document.getElementById(id).addEventListener("click", () => {
    sfx.ensure(); sfx.play("click"); fn();
  });
}
on("btn-start", () => startAt(Math.min(game.progress.unlocked - 1, LEVELS.length - 1)));
on("btn-newgame", () => startAt(0));
on("btn-resume", togglePause);
on("btn-pause-restart", () => { game.loadLevel(game.levelIndex); showOverlay(null); });
on("btn-pause-menu", backToMenu);
on("btn-next", () => {
  if (game.levelIndex + 1 < LEVELS.length) {
    game.loadLevel(game.levelIndex + 1);
    showOverlay(null);
  } else {
    const best = Object.values(game.progress.best).reduce((a, b) => a + b, 0);
    document.getElementById("alldone-stars").textContent =
      `收集星星总计 ★ ${best} / ${LEVELS.length * 3}`;
    game.state = "ALL_DONE";
    showOverlay("ov-alldone");
  }
});
on("btn-replay", () => { startAt(game.levelIndex); });
on("btn-done-menu", backToMenu);
on("btn-retry", () => startAt(game.levelIndex));
on("btn-gameover-menu", backToMenu);
on("btn-again", () => startAt(0));
on("btn-alldone-menu", backToMenu);
on("btn-restart", () => { if (game.state === "PLAYING" || game.state === "PAUSED") { game.loadLevel(game.levelIndex); showOverlay(null); } });
on("btn-pause", togglePause);
on("btn-sound", () => { sfx.setMuted(!sfx.muted); updateSoundIcon(); });

// ---- 键盘 ----
const KEY_LEFT = ["ArrowLeft", "KeyA"];
const KEY_RIGHT = ["ArrowRight", "KeyD"];
const KEY_JUMP = ["Space", "ArrowUp", "KeyW"];

window.addEventListener("keydown", (e) => {
  if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) {
    e.preventDefault();
  }
  if (e.repeat) return;
  sfx.ensure();

  if (KEY_LEFT.includes(e.code)) game.input.left = true;
  if (KEY_RIGHT.includes(e.code)) game.input.right = true;
  if (KEY_JUMP.includes(e.code)) { game.input.jumpHeld = true; game.ball.jumpLock = false; }

  switch (e.code) {
    case "Enter":
      if (game.state === "MENU") startAt(Math.min(game.progress.unlocked - 1, LEVELS.length - 1));
      else if (game.state === "LEVEL_DONE") document.getElementById("btn-next").click();
      else if (game.state === "GAME_OVER") startAt(game.levelIndex);
      else if (game.state === "ALL_DONE") backToMenu();
      else if (game.state === "PAUSED") togglePause();
      break;
    case "Escape":
    case "KeyP":
      if (game.state === "PLAYING" || game.state === "PAUSED") togglePause();
      break;
    case "KeyR":
      if (game.state === "PLAYING") game.loadLevel(game.levelIndex);
      break;
    case "KeyG":
      game.flipGravity();
      break;
    case "KeyM":
      sfx.setMuted(!sfx.muted);
      updateSoundIcon();
      break;
  }
});

window.addEventListener("keyup", (e) => {
  if (KEY_LEFT.includes(e.code)) game.input.left = false;
  if (KEY_RIGHT.includes(e.code)) game.input.right = false;
  if (KEY_JUMP.includes(e.code)) cutJump();
});

// ---- 触屏 ----
if ("ontouchstart" in window || navigator.maxTouchPoints > 0) {
  document.getElementById("touch").classList.remove("hidden");
  document.querySelectorAll(".tbtn").forEach((btn) => {
    const k = btn.dataset.k;
    const press = (e) => {
      e.preventDefault();
      sfx.ensure();
      if (k === "left") game.input.left = true;
      else if (k === "right") game.input.right = true;
      else if (k === "jump") { game.input.jumpHeld = true; game.ball.jumpLock = false; }
      else if (k === "gravity") game.flipGravity();
    };
    const release = (e) => {
      e.preventDefault();
      if (k === "left") game.input.left = false;
      else if (k === "right") game.input.right = false;
      else if (k === "jump") cutJump();
    };
    btn.addEventListener("pointerdown", press);
    btn.addEventListener("pointerup", release);
    btn.addEventListener("pointercancel", release);
    btn.addEventListener("pointerleave", release);
  });
}

// 切出页面自动暂停
document.addEventListener("visibilitychange", () => {
  if (document.hidden && game.state === "PLAYING") togglePause();
});

// ---- 主循环：定步长物理 + rAF 渲染 ----
let last = performance.now();
let acc = 0;
function frame(now) {
  let dt = now - last;
  last = now;
  if (dt > 100) dt = 100;      // 后台切回防跳变
  acc += dt;
  while (acc >= STEP_MS) {
    game.step();
    acc -= STEP_MS;
  }
  game.resize();
  game.render();
  requestAnimationFrame(frame);
}

// 启动：先加载第 1 关作为菜单背景
game.loadLevel(0);
game.state = "MENU";
updateSoundIcon();
refreshMenu();
updateHud();
requestAnimationFrame(frame);

})();
