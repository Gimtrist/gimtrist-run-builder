/* -*- coding: utf-8 -*-
 * 音效：WebAudio 纯合成，无外部资源。
 * 首次用户手势时初始化 AudioContext（浏览器自动播放策略）。
 */
"use strict";

class Sfx {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.muted = false;
    try {
      this.muted = localStorage.getItem("bb.muted") === "1";
    } catch (e) { /* file:// 下可能被禁用 */ }
  }

  /** 必须在用户手势里调用一次 */
  ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") this.ctx.resume();
  }

  setMuted(m) {
    this.muted = m;
    try { localStorage.setItem("bb.muted", m ? "1" : "0"); } catch (e) {}
  }

  /** 基础音：频率 f0→f1 线性滑动，指数衰减包络 */
  tone(f0, f1, dur, type = "sine", vol = 0.16, delay = 0) {
    if (this.muted || !this.ctx) return;
    const t0 = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, f0), t0);
    osc.frequency.linearRampToValueAtTime(Math.max(20, f1), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(this.master);
    osc.start(t0); osc.stop(t0 + dur + 0.05);
  }

  play(name) {
    if (this.muted || !this.ctx) return;
    switch (name) {
      case "jump":   this.tone(300, 540, 0.12, "square", 0.10); break;
      case "land":   this.tone(170, 90, 0.08, "triangle", 0.12); break;
      case "star":   this.tone(880, 880, 0.09, "sine", 0.14);
                     this.tone(1318, 1318, 0.12, "sine", 0.12, 0.07); break;
      case "spring": this.tone(180, 900, 0.18, "square", 0.12); break;
      case "death":  this.tone(340, 55, 0.4, "sawtooth", 0.16);
                     this.tone(240, 40, 0.4, "square", 0.08, 0.03); break;
      case "portal": this.tone(420, 980, 0.14, "sine", 0.12);
                     this.tone(980, 420, 0.14, "sine", 0.10, 0.12); break;
      case "flip":   this.tone(600, 200, 0.16, "triangle", 0.12);
                     this.tone(200, 600, 0.16, "triangle", 0.10, 0.14); break;
      case "win":    [523, 659, 784, 1046].forEach((f, i) =>
                       this.tone(f, f, 0.14, "triangle", 0.13, i * 0.09)); break;
      case "click":  this.tone(700, 700, 0.05, "sine", 0.07); break;
    }
  }
}

const sfx = new Sfx();
