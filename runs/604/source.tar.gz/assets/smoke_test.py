# -*- coding: utf-8 -*-
"""冒烟测试：验证关卡加载、关键对象存在、物理模拟不崩溃。"""
import os
import sys

# 使用哑视频驱动，避免需要图形界面
os.environ['SDL_VIDEODRIVER'] = 'dummy'
os.environ['SDL_AUDIODRIVER'] = 'dummy'

import pygame
import main

def test_levels():
    print(f"关卡数量: {len(main.LEVELS)}")
    for i, raw in enumerate(main.LEVELS):
        ld = main.parse_level(raw)
        ok = True
        msgs = []
        if ld['spawn'] is None:
            ok = False; msgs.append("缺出生点")
        if ld['goal'] is None:
            ok = False; msgs.append("缺终点")
        # grid 尺寸
        h = len(ld['grid'])
        w = len(ld['grid'][0]) if h else 0
        if h != main.ROWS or w != main.COLUMNS:
            msgs.append(f"尺寸异常 {h}x{w}")
        stars = len(ld['stars'])
        spikes = len(ld['spikes'])
        springs = len(ld['springs'])
        moving = len(ld['moving'])
        portals = sum(1 for v in ld['portals'].values() if v)
        print(f"  第{i+1}关: spawn={ld['spawn']} goal={ld['goal']} "
              f"星{stars} 刺{spikes} 簧{springs} 动{moving} 门{portals} -> "
              f"{'OK' if ok else 'FAIL '+','.join(msgs)}")
        assert ok, f"第{i+1}关无效: {msgs}"

def test_simulate():
    """模拟每关跑 300 帧，确保 update 不抛异常。"""
    g = main.Game()
    for i in range(len(main.LEVELS)):
        g.load_level(i)
        try:
            for _ in range(300):
                g.handle_input()
                g.update()
        except Exception as e:
            raise AssertionError(f"第{i+1}关模拟崩溃: {e}")
    print("模拟 8 关 x 300 帧：无异常 OK")

def test_portal_pair():
    # 第7关应有传送门对
    ld = main.parse_level(main.LEVELS[6])
    assert ld['portals']['A'] and ld['portals']['B'], "第7关缺传送门对"
    print("第7关传送门对存在 OK")

def test_render():
    """渲染每关 + 各状态画面，确保绘制逻辑不抛异常。"""
    g = main.Game()
    states = ['MENU', 'GAME_OVER', 'ALL_DONE']
    for s in states:
        g.state = s
        g.level_data = None
        try:
            g.render()
        except Exception as e:
            raise AssertionError(f"状态 {s} 渲染崩溃: {e}")
    for i in range(len(main.LEVELS)):
        g.load_level(i)
        try:
            g.render()
            g.state = 'LEVEL_DONE'
            g.render()
        except Exception as e:
            raise AssertionError(f"第{i+1}关渲染崩溃: {e}")
    print("渲染全部关卡 + 状态画面：无异常 OK")

if __name__ == '__main__':
    test_levels()
    test_simulate()
    test_portal_pair()
    test_render()
    print("\n全部冒烟测试通过 ✅")
