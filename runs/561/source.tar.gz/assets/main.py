# XS-Midi-Player v2 -- MIDI visualizer player + rhythm mini-game.
# Dependencies: pygame, pretty_midi (pip install pygame pretty_midi)
import os

import pygame

import midi_reader
import midi_shower
import midi_sounder
import open_file_path
import settings as settings_mod
from lang import tr

GAME_PERFECT_MS = 60  # Perfect: |deviation| <= 60ms
GAME_GOOD_MS = 120  # Good: 60ms < |deviation| <= 120ms; beyond that = Miss
GAME_MAX_SCORE = 1_000_000
FONT_NAMES = ("microsoftyahei", "simhei", "msyh", "simsun", "arial")
ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
TOOLTIP_KEYS = (
    "open_midi",
    "toggle_orientation",
    "settings",
    "play_pause",
    "game_mode",
    "seek",
)


def make_font(size):
    """Return a font that supports Chinese; SysFont crashes on some Windows machines,
    so fall back through several options."""
    try:
        for name in FONT_NAMES:
            font = pygame.font.SysFont(name, size)
            if font is not None:
                return font
    except Exception:
        pass
    for path in (
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/msyh.ttf",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc",
    ):
        if os.path.exists(path):
            return pygame.font.Font(path, size)
    return pygame.font.Font(None, size)


def fmt_time(seconds):
    """Format seconds as m:ss."""
    s = max(0, int(seconds))
    return f"{s // 60}:{s % 60:02d}"


class GameState:
    """Game-mode state: judgment, score (max fixed at 1000000), accuracy, combo."""

    def __init__(self, notes):
        self.notes = sorted(notes, key=lambda n: n.start)
        self.n = len(self.notes)
        self.per_note = GAME_MAX_SCORE / self.n if self.n else 0.0
        self.idx = 0  # first unjudged note in start-time order
        self.judged = [False] * self.n
        self.judged_by_id = [False] * self.n  # indexed by note id (for rendering)
        self.perfect = self.good = self.miss = 0
        self.score = 0.0
        self.combo = 0
        self.max_combo = 0
        self.flash = None  # (text, color, time)

    @property
    def judged_count(self):
        return self.perfect + self.good + self.miss

    @property
    def accuracy(self):
        if self.judged_count == 0:
            return 1.0
        return self.score / (self.per_note * self.judged_count)

    def _judge(self, i, t, is_miss):
        if is_miss:
            self.miss += 1
            self.combo = 0
            self.flash = ("Miss", pygame.Color(255, 90, 90), t)
        else:
            # Tiny tolerance so a hit exactly on the boundary counts as the better grade
            if abs(self.notes[i].start - t) <= GAME_PERFECT_MS / 1000.0 + 1e-9:
                self.perfect += 1
                self.score += self.per_note
                self.flash = ("Perfect", pygame.Color(255, 215, 80), t)
            else:
                self.good += 1
                self.score += self.per_note / 2.0
                self.flash = ("Good", pygame.Color(110, 170, 255), t)
            self.combo += 1
            self.max_combo = max(self.max_combo, self.combo)
        self.judged[i] = True
        self.judged_by_id[self.notes[i].id] = True
        while self.idx < self.n and self.judged[self.idx]:
            self.idx += 1

    def press(self, t):
        """Key press: judge the unjudged note nearest the border within +/-Good (one per press)."""
        limit = GAME_GOOD_MS / 1000.0 + 1e-9
        best, best_dt = -1, 0.0
        i = self.idx
        while i < self.n and self.notes[i].start <= t + limit:
            if not self.judged[i]:
                dt = abs(self.notes[i].start - t)
                if dt <= limit and (best < 0 or dt < best_dt):
                    best, best_dt = i, dt
            i += 1
        if best >= 0:
            self._judge(best, t, False)

    def update(self, t):
        """Notes that passed the Good window without a press become Miss."""
        limit = GAME_GOOD_MS / 1000.0
        while self.idx < self.n and self.notes[self.idx].start < t - limit:
            if not self.judged[self.idx]:
                self._judge(self.idx, t, True)
            else:
                self.idx += 1

    def finish(self):
        """Song over: all remaining unjudged notes become Miss."""
        while self.idx < self.n:
            if not self.judged[self.idx]:
                self._judge(self.idx, 1e9, True)
            else:
                self.idx += 1


class App:
    def __init__(self):
        pygame.init()
        pygame.midi.init()
        self.settings = settings_mod.Settings()
        self.w, self.h = 800, 600
        self.screen = pygame.display.set_mode((self.w, self.h), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        self.font = make_font(20)
        self.font_small = make_font(14)
        self.font_big = make_font(32)
        self.tooltips = {}
        self._build_tooltips()

        self.instruments = []
        self.notes = []
        self.t_note_last = -1.0
        self.sounder = None
        self.shower = None
        self._sounder_device = -1

        self.t = -2.0
        self.is_paused = False
        self.is_vertical = False
        self.is_game = False
        self.game = None
        self._dragging = False  # whether the progress bar is being dragged

        self.notes_surface = None
        self.notes_pos = (0, 0)
        self.buttons = {}
        self.progress_rect = pygame.Rect(0, 0, 0, 0)
        self.icons = {
            name: pygame.image.load(os.path.join(ASSET_DIR, name + ".png"))
            for name in (
                "file",
                "vertical",
                "horizontal",
                "settings",
                "pause",
                "resume",
                "game",
                "view",
            )
        }
        self.update_layout()
        path = open_file_path.open_file_path(tr(self.settings.lang, "open_title"))
        if path:
            self.load_file(path)

    def _build_tooltips(self):
        lang = self.settings.lang
        texts = [tr(lang, k) for k in TOOLTIP_KEYS]
        self.tooltips = dict(
            zip(("file", "vertical", "settings", "pause", "game", "progress"), texts)
        )

    # ---------- time and sound ----------
    def sound_time(self):
        return self.t - self.settings.sound_offset / 1000.0

    def set_time(self, t):
        self.t = t
        if self.sounder is not None:
            self.sounder.set_time(self.sound_time())

    def load_file(self, path):
        mr = midi_reader.MidiReader(path)
        self.instruments = mr.get_instruments_info()
        self.notes = mr.get_notes()
        if self.sounder is not None:
            # Reuse the open MIDI output so opening a file never re-opens the device
            self.sounder.reset(self.instruments, self.notes)
        else:
            self.sounder = midi_sounder.MidiSounder(
                self.instruments, self.notes, self.settings.device_id
            )
            self._sounder_device = self.settings.device_id
        if self.notes:
            self.t_note_last = max(n.end for n in self.notes)
            note_highest = max(n.pitch for n in self.notes) + 1
            note_lowest = min(n.pitch for n in self.notes) - 1
        else:
            self.t_note_last = -1.0
            note_highest, note_lowest = 93, 45
        self.shower = midi_shower.MidiShower(
            self.notes_surface,
            self.notes,
            note_lowest=note_lowest,
            note_highest=note_highest,
            note_border_width=self.settings.note_border_width,
            t_window=self.settings.t_window,
            is_vertical=self.is_vertical,
        )
        self.shower.apply_settings(self.settings)
        self.is_game = False
        self.game = None
        self.is_paused = False
        self.set_time(-2.0)

    def apply_settings(self):
        """Called after settings change: colors/speed/border apply immediately;
        a device change rebuilds the sounder. Also refreshes translated UI strings."""
        self._build_tooltips()
        if self.shower is not None:
            self.shower.apply_settings(self.settings)
        if self.settings.device_id != self._sounder_device:
            if self.sounder is not None:
                self.sounder.close()
            self.sounder = midi_sounder.MidiSounder(
                self.instruments, self.notes, self.settings.device_id
            )
            self._sounder_device = self.settings.device_id
            self.sounder.set_time(self.sound_time())

    # ---------- layout ----------
    def update_layout(self):
        w, h = self.w, self.h
        names = ("file", "vertical", "settings", "pause", "game")
        if self.is_vertical:
            self.notes_pos = (20, 0)
            self.notes_surface = pygame.Surface((w - 80, h))
            xs = w - 40
            self.buttons = {
                n: self.icons[n].get_rect(topleft=(xs, y))
                for n, y in zip(names, (20, 50, 80, 110, 140))
            }
            self.progress_rect = pygame.Rect(w - 40, 170, 20, h - 330)
        else:
            self.notes_pos = (0, 20)
            self.notes_surface = pygame.Surface((w, h - 80))
            self.buttons = {
                n: self.icons[n].get_rect(topleft=(x, h - 40))
                for n, x in zip(names, (20, 50, 80, 110, 140))
            }
            self.progress_rect = pygame.Rect(170, h - 40, w - 200, 20)
        if self.shower is not None:
            self.shower.set_surface(self.notes_surface)
            self.shower.set_vertical(self.is_vertical)

    # ---------- interaction ----------
    def toggle_pause(self):
        self.is_paused = not self.is_paused
        if self.is_paused:
            if self.sounder is not None:
                self.sounder.pause()
        elif self.t >= self.t_note_last + 2:
            # Play pressed after the song ended: restart from the beginning
            self.set_time(-2.0)
            if self.is_game:
                self.game = GameState(self.notes)

    def toggle_game(self):
        if self.is_game:
            self.is_game = False
            self.game = None
        elif self.notes:
            self.is_game = True
            self.game = GameState(self.notes)
            self.is_paused = False
            self.set_time(-2.0)  # music restarts from the beginning

    def seek(self, pos):
        r = self.progress_rect
        if self.is_vertical:
            progress = 1.0 - (pos[1] - r.top) / r.height
        else:
            progress = (pos[0] - r.left) / r.width
        progress = max(0.0, min(1.0, progress))
        self.set_time(progress * (self.t_note_last + 4) - 2)

    def open_settings(self):
        if self.sounder is not None:
            self.sounder.pause()
        was_paused = self.is_paused
        self.is_paused = True
        settings_mod.show_settings_window(self.settings, self.apply_settings)
        self.settings.save()
        self.is_paused = was_paused

    # ---------- main loop ----------
    def run(self):
        # Create the Clock only when the loop starts; otherwise the first tick()
        # would include the file dialog time and the song would start mid-way.
        self.clock = pygame.time.Clock()
        running = True
        while running:
            pause_toggled = False
            new_file = None

            if self.t >= self.t_note_last + 2 and not self.is_paused:
                if self.is_game and self.game is not None:
                    self.game.finish()
                pause_toggled = True  # auto-pause when the song ends

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.VIDEORESIZE:
                    self.w, self.h = max(event.w, 400), max(event.h, 400)
                    self.screen = pygame.display.set_mode(
                        (self.w, self.h), pygame.RESIZABLE
                    )
                    self.update_layout()
                elif event.type == pygame.DROPFILE:
                    new_file = event.file
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        pause_toggled = True
                    elif self.is_game and not self.is_paused and self.game is not None:
                        self.game.press(self.t)
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    if self.progress_rect.collidepoint(pos):
                        if not self.is_game:  # no seeking while in game mode
                            self._dragging = True
                            self.seek(pos)
                    elif self.buttons["file"].collidepoint(pos):
                        if self.sounder is not None:
                            self.sounder.pause()
                        path = open_file_path.open_file_path(
                            tr(self.settings.lang, "open_title")
                        )
                        if path:
                            new_file = path
                    elif self.buttons["vertical"].collidepoint(pos):
                        self.is_vertical = not self.is_vertical
                        self.w, self.h = self.h, self.w
                        self.screen = pygame.display.set_mode(
                            (self.w, self.h), pygame.RESIZABLE
                        )
                        self.update_layout()
                    elif self.buttons["settings"].collidepoint(pos):
                        self.open_settings()
                    elif self.buttons["pause"].collidepoint(pos):
                        pause_toggled = True
                    elif self.buttons["game"].collidepoint(pos):
                        self.toggle_game()
                elif event.type == pygame.MOUSEMOTION:
                    if self._dragging and not self.is_game:
                        self.seek(event.pos)  # hold and drag to seek
                elif event.type == pygame.MOUSEBUTTONUP:
                    self._dragging = False

            if new_file:
                try:
                    self.load_file(new_file)
                except Exception as e:
                    print(f"Failed to read file {new_file}: {e}")

            if pause_toggled:
                self.toggle_pause()

            # Releasing the button outside the window may miss MOUSEBUTTONUP;
            # fall back to checking the physical button state each frame.
            if self._dragging and not pygame.mouse.get_pressed()[0]:
                self._dragging = False

            self.update()
            self.draw()
            pygame.display.flip()
            # Clamp the frame delta so long blocking (file dialog, settings window)
            # never jumps the timeline.
            dt = min(self.clock.tick(240) / 1000, 0.1)
            if not self.is_paused:
                self.t += dt

        if self.sounder is not None:
            self.sounder.close()
        self.settings.save()
        pygame.midi.quit()
        pygame.quit()

    def update(self):
        if self.sounder is not None and not self.is_paused:
            self.sounder.update(self.sound_time())
        if self.is_game and self.game is not None and not self.is_paused:
            self.game.update(self.t)

    def draw(self):
        bg = self.settings.bg_color
        self.screen.fill(bg)
        if self.notes_surface is not None:
            self.notes_surface.fill(bg)
        if self.shower is not None:
            # Notes must be drawn after the fill, or the previous frame is erased
            self.shower.set_judged(
                self.game.judged_by_id
                if (self.is_game and self.game is not None)
                else None
            )
            self.shower.update(self.t)

        # progress bar
        total = max(1.0, self.t_note_last + 4)
        progress = max(0.0, min(1.0, (self.t + 2) / total))
        r = self.progress_rect
        if self.is_vertical:
            fill = pygame.Rect(
                r.left,
                r.top + int(r.height * (1 - progress)),
                r.width,
                int(r.height * progress),
            )
        else:
            fill = pygame.Rect(r.left, r.top, int(r.width * progress), r.height)
        pygame.draw.rect(self.screen, pygame.Color(127, 127, 127), fill)
        pygame.draw.rect(self.screen, pygame.Color(255, 255, 255), r, 2)

        # notes and buttons
        if self.shower is not None:
            self.screen.blit(self.notes_surface, self.notes_pos)
        for name in ("file", "vertical", "settings", "pause", "game"):
            self.screen.blit(self.icons[self._icon_for(name)], self.buttons[name])

        # game HUD: score / accuracy / combo + judgment feedback
        if self.is_game and self.game is not None:
            g = self.game
            lang = self.settings.lang
            hud = self.font.render(
                f"{tr(lang, 'score')} {int(round(g.score))}   "
                f"{tr(lang, 'accuracy')} {g.accuracy * 100:.1f}%   "
                f"{tr(lang, 'combo')} {g.combo}",
                True,
                pygame.Color(255, 255, 255),
            )
            self.screen.blit(hud, (10, 4))
            if g.flash is not None and self.t - g.flash[2] < 0.6:
                label, color, _ = g.flash
                flash = self.font_big.render(label, True, color)
                self.screen.blit(flash, flash.get_rect(center=(self.w // 2, 40)))

        # time display (top-right; shifted left of the button column in vertical mode)
        if self.settings.show_time:
            total = self.t_note_last if self.t_note_last > 0 else 0.0
            cur = min(max(0.0, self.t), total) if total > 0 else max(0.0, self.t)
            time_surf = self.font.render(
                f"{fmt_time(cur)} / {fmt_time(total)}",
                True,
                pygame.Color(255, 255, 255),
            )
            self.screen.blit(
                time_surf,
                time_surf.get_rect(
                    topright=(self.w - (44 if self.is_vertical else 8), 4)
                ),
            )

        self.draw_tooltip()

    def draw_tooltip(self):
        """Show a description box when the mouse hovers over a button or the progress bar."""
        if not self.settings.show_tooltip:
            return
        pos = pygame.mouse.get_pos()
        if not self.screen.get_rect().collidepoint(pos):
            return
        name = None
        for n, rect in self.buttons.items():
            if rect.collidepoint(pos):
                name = n
                break
        if name is None and self.progress_rect.collidepoint(pos):
            name = "progress"
        text = self.tooltips.get(name)
        if text is None:
            return
        text_surf = self.font_small.render(text, True, pygame.Color(255, 255, 255))
        pad = 4
        w = text_surf.get_width() + pad * 2
        h = text_surf.get_height() + pad * 2
        anchor = self.progress_rect if name == "progress" else self.buttons[name]
        if self.is_vertical:
            x = max(4, anchor.left - w - 8)
            y = anchor.top
        else:
            x = max(4, min(anchor.left + anchor.width // 2 - w // 2, self.w - w - 4))
            y = anchor.top - h - 8
            if y < 4:
                y = anchor.bottom + 8
        box = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, pygame.Color(40, 40, 40), box)
        pygame.draw.rect(self.screen, pygame.Color(180, 180, 180), box, 1)
        self.screen.blit(text_surf, (x + pad, y + pad))

    def _icon_for(self, name):
        if name == "vertical":
            return "horizontal" if self.is_vertical else "vertical"
        if name == "pause":
            return "resume" if self.is_paused else "pause"
        if name == "game":
            return "view" if self.is_game else "game"
        return name


if __name__ == "__main__":
    App().run()
