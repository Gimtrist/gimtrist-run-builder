# open_file_path.py - File selection dialog (tkinter).
import tkinter as tk
from tkinter import filedialog
from typing import Optional


def open_file_path(title: str = "Open file") -> Optional[str]:
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title=title,
        filetypes=[("Midi files", "*.mid *.midi *.smf"), ("All files", "*.*")],
    )
    root.destroy()
    if file_path:
        return file_path
    return None
