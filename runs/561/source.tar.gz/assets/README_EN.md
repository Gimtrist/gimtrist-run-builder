# XS-Midi-Player v2
[中文](README.md) | English

A MIDI visualizer player and rhythm mini-game built with pygame + pretty_midi + tkinter.
Refactored from the older XS-Midi-Player: the minimal look and layout are kept,
bugs were fixed, and a settings screen plus a game mode were added.

## Run

```bash
pip install -r requirements.txt
python main.py
```

A file dialog opens at startup; you can also drag a `.mid` file into the window.

## Controls

| Button / key              | Action                                                          |
| ------------------------- | --------------------------------------------------------------- |
| File button / drag file   | Open a MIDI file                                                |
| Orientation button        | Toggle horizontal / vertical scrolling                          |
| Settings button           | Open the settings window (saved to settings.json automatically) |
| Play/pause button / Space | Play / pause; pressing play after the song ends restarts it     |
| Game button               | Enter / exit game mode (music restarts from the beginning)      |

## Game mode

Press any key when a note reaches the screen border (horizontal: left edge,
vertical: bottom edge). Each note needs only one press:

- Perfect: |deviation| <= 60ms, full score
- Good: 60ms < |deviation| <= 120ms, half score
- Miss: not pressed before leaving the window, 0 points (breaks the combo)

The maximum score is fixed at 1,000,000. Score, accuracy and combo are shown in the
top-left corner, and the judgment result flashes in the center of the screen.
Chords need one press per note (each press judges the note nearest the border).
The song pauses automatically when finished (final score stays on screen, no
results screen); press play again to start a new game.

## Settings

The settings window has two tabs; the "Reset defaults / Close" buttons at the
bottom are always visible:

- Playback tab: language, show-time toggle, show-tooltips toggle, note speed,
  note display style, sound offset, note border width, MIDI output device
- Colors tab: background color, note and border colors for 16 channels

Settings are stored in settings.json next to the program and restored on startup.

## Misc

- Current / total time is shown in the top-right corner.
- Hovering over a button or the progress bar shows a description.
- Click or drag the progress bar to seek (disabled in game mode).
- MIDI parsing: pretty_midi only reads tempo events from track 0; this program
  automatically merges tempo events from other tracks into track 0, so songs with
  a non-120 BPM tempo no longer play at the wrong speed.

## Files

- `main.py` main program (UI, main loop, game mode)
- `midi_reader.py` MIDI parsing (pretty_midi + tempo-map fix)
- `midi_sounder.py` sends note events to the MIDI output by time
- `midi_shower.py` note rendering (horizontal / vertical scrolling)
- `settings.py` settings data + tkinter settings window
- `lang.py` UI strings (Simplified Chinese / English)
- `open_file_path.py` file dialog
- `assets/` button icons, `midi_examples/` sample MIDI files
