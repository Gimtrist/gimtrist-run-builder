# midi_sounder.py - Send note events to a MIDI output device on a timeline.
import contextlib
import io

import pygame.midi


@contextlib.contextmanager
def _silence_midi_output():
    """Silence device probing: PortMidi prints failures directly to Python
    stdout/stderr (which stream varies by platform/version), so swallow both."""
    sink = io.StringIO()
    with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
        yield


def _list_candidates(device_id):
    """Candidate devices: requested -> default -> every other output device."""
    ids = []
    for did in (device_id, pygame.midi.get_default_output_id()):
        if did >= 0 and did not in ids:
            ids.append(did)
    try:
        for i in range(pygame.midi.get_count()):
            if pygame.midi.get_device_info(i)[3] == 1 and i not in ids:
                ids.append(i)
    except Exception:
        pass
    return ids


class MidiSounder:
    """Send note events to a MIDI output device by time (runs muted if no device works)."""

    def __init__(self, instruments, notes, device_id=None):
        pygame.midi.init()
        if device_id is None or device_id < 0:
            device_id = pygame.midi.get_default_output_id()
        self._device_id = device_id
        self._midi_output = None

        for did in _list_candidates(device_id):
            out = None
            try:
                with _silence_midi_output():
                    out = pygame.midi.Output(did)
                    out.write_short(0xB0, 123, 0)  # probe: send All Notes Off
                    for instrument in instruments:
                        out.set_instrument(instrument["program"], instrument["channel"])
                self._midi_output = out
                self._device_id = did
                break
            except Exception:
                if out is not None:
                    try:
                        out.close()
                    except Exception:
                        pass
                # A failed open can poison PortMidi's device table; re-init before retrying
                try:
                    pygame.midi.quit()
                    pygame.midi.init()
                except Exception:
                    pass
        if self._midi_output is None:
            print("No usable MIDI output device; playing muted.")
        elif self._device_id != device_id:
            print(
                f"MIDI device {device_id} unavailable, switched to device {self._device_id}."
            )

        self._notes = notes
        self._notes_by_id = sorted(self._notes, key=lambda x: x.id)
        self._note_is_on = [False] * len(self._notes)

        # All note_on / note_off events sorted by time; at the same time, off before on
        self._events = []
        for note in self._notes:
            self._events.append((note.start, 2, note.id, note))
            self._events.append((note.end, 1, note.id, note))
        self._events.sort()
        self._event_idx = 0

    def reset(self, instruments, notes):
        """Switch songs: keep the open MIDI output, only reset events and programs
        (avoids re-opening the device on every file load)."""
        self.pause()
        self._notes = notes
        self._notes_by_id = sorted(self._notes, key=lambda x: x.id)
        self._note_is_on = [False] * len(self._notes)
        self._events = []
        for note in self._notes:
            self._events.append((note.start, 2, note.id, note))
            self._events.append((note.end, 1, note.id, note))
        self._events.sort()
        self._event_idx = 0
        if self._midi_output is not None:
            try:
                for instrument in instruments:
                    self._midi_output.set_instrument(
                        instrument["program"], instrument["channel"]
                    )
            except Exception:
                pass

    def update(self, t: float):
        while (
            self._event_idx < len(self._events)
            and self._events[self._event_idx][0] <= t
        ):
            _, event_type, _, note = self._events[self._event_idx]
            if self._midi_output is not None:
                if event_type == 2 and not self._note_is_on[note.id]:
                    self._midi_output.note_on(note.pitch, note.velocity, note.channel)
                    self._note_is_on[note.id] = True
                elif event_type == 1 and self._note_is_on[note.id]:
                    self._midi_output.note_off(note.pitch, note.velocity, note.channel)
                    self._note_is_on[note.id] = False
            self._event_idx += 1

    def pause(self):
        if self._midi_output is None:
            return
        for i, is_on in enumerate(self._note_is_on):
            if is_on:
                note = self._notes_by_id[i]
                self._midi_output.note_off(note.pitch, note.velocity, note.channel)
                self._note_is_on[i] = False

    def set_time(self, t: float):
        self.pause()
        if not self._events:
            return
        lo, hi = 0, len(self._events)
        while hi > lo:
            mid = (lo + hi) // 2
            if self._events[mid][0] >= t:
                hi = mid
            else:
                lo = mid + 1
        self._event_idx = lo

    def close(self):
        try:
            self.pause()
            if self._midi_output is not None:
                self._midi_output.close()
                self._midi_output = None
        except Exception:
            pass
