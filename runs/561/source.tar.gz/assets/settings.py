# settings.py - Settings data (auto-saved to settings.json) + tkinter settings window.
import json
import os
import tkinter as tk
from tkinter import colorchooser, ttk

import pygame

from lang import tr

N_CHANNELS = 16
CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.json")


def _rgb(c):
    return [c.r, c.g, c.b]


class Settings:
    """All tunable parameters. load() runs at startup, save() when the window closes."""

    def __init__(self):
        self.bg_color = pygame.Color(0, 0, 0)
        self.note_colors = [pygame.Color(255, 255, 255) for _ in range(N_CHANNELS)]
        self.note_border_colors = [
            pygame.Color(127, 127, 127) for _ in range(N_CHANNELS)
        ]
        self.t_window = 0.5  # visible time window in seconds; smaller = faster notes
        self.note_border_width = 1
        self.note_style = (
            0  # 0=auto (border-only after note starts) 1=game-judged 2=always solid
        )
        self.sound_offset = (
            -250
        )  # ms to play sound early (compensates MIDI output latency)
        self.device_id = -1  # -1 = default MIDI output device
        self.show_time = True  # show the current/total time display (top-right)
        self.show_tooltip = True  # show tooltips when hovering buttons / progress bar
        self.lang = "zh"  # UI language: "zh" or "en"
        self.load()

    def load(self):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                d = json.load(f)
            if "bg_color" in d:
                self.bg_color = pygame.Color(*d["bg_color"])
            if "note_colors" in d:
                for i, c in enumerate(d["note_colors"][:N_CHANNELS]):
                    self.note_colors[i] = pygame.Color(*c)
            if "note_border_colors" in d:
                for i, c in enumerate(d["note_border_colors"][:N_CHANNELS]):
                    self.note_border_colors[i] = pygame.Color(*c)
            if "t_window" in d:
                self.t_window = float(d["t_window"])
            if "note_border_width" in d:
                self.note_border_width = int(d["note_border_width"])
            if "note_style" in d:
                self.note_style = int(d["note_style"])
            if "sound_offset" in d:
                self.sound_offset = int(d["sound_offset"])
            if "device_id" in d:
                self.device_id = int(d["device_id"])
            if "show_time" in d:
                self.show_time = bool(d["show_time"])
            if "show_tooltip" in d:
                self.show_tooltip = bool(d["show_tooltip"])
            if "lang" in d:
                self.lang = d["lang"] if d["lang"] in ("zh", "en") else "zh"
        except Exception:
            pass  # missing or corrupt config file: keep defaults

    def save(self):
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "bg_color": _rgb(self.bg_color),
                        "note_colors": [_rgb(c) for c in self.note_colors],
                        "note_border_colors": [
                            _rgb(c) for c in self.note_border_colors
                        ],
                        "t_window": self.t_window,
                        "note_border_width": self.note_border_width,
                        "note_style": self.note_style,
                        "sound_offset": self.sound_offset,
                        "device_id": self.device_id,
                        "show_time": self.show_time,
                        "show_tooltip": self.show_tooltip,
                        "lang": self.lang,
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
        except Exception as e:
            print("Failed to save settings:", e)

    def reset_defaults(self):
        self.bg_color = pygame.Color(0, 0, 0)
        self.note_colors = [pygame.Color(255, 255, 255) for _ in range(N_CHANNELS)]
        self.note_border_colors = [
            pygame.Color(127, 127, 127) for _ in range(N_CHANNELS)
        ]
        self.t_window = 0.5
        self.note_border_width = 1
        self.note_style = 0
        self.sound_offset = -250
        self.device_id = -1
        self.show_time = True
        self.show_tooltip = True


def get_midi_devices():
    """Return [(device_id, name), ...] for output devices only. Requires pygame.midi.init()."""
    devices = []
    try:
        for i in range(pygame.midi.get_count()):
            info = pygame.midi.get_device_info(i)
            if info[3] == 1:  # output device
                name = (
                    info[1].decode(errors="replace")
                    if isinstance(info[1], bytes)
                    else str(info[1])
                )
                devices.append((i, name))
    except Exception:
        pass
    return devices


class SettingsWindow:
    """Modal settings window with two tabs (Playback / Colors).
    Changes apply immediately (via apply_cb); the caller saves."""

    def __init__(self, settings, apply_cb, initial_tab=0):
        self.settings = settings
        self.apply_cb = apply_cb
        self.restart = (
            False  # set True when the language changes, so the window rebuilds
        )
        self.tab_index = 0  # tab selected when the window was closed (for rebuild)
        lang = settings.lang
        self.root = tk.Tk()
        self.root.title(tr(lang, "settings_title"))
        self.root.geometry("560x520")
        self.root.resizable(False, True)

        body = tk.Frame(self.root)
        body.pack(fill="both", expand=True, padx=12, pady=10)

        # -- tabs: playback / colors --
        self.notebook = ttk.Notebook(body)
        self.notebook.pack(fill="both", expand=True)
        tab_play = ttk.Frame(self.notebook)
        tab_colors = ttk.Frame(self.notebook)
        self.notebook.add(tab_play, text=tr(lang, "tab_playback"))
        self.notebook.add(tab_colors, text=tr(lang, "tab_colors"))
        if initial_tab:
            self.notebook.select(initial_tab)

        # ================= tab 1: playback =================
        # -- language --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "language"), width=14, anchor="w").pack(side="left")
        self.lang_var = tk.StringVar(value=settings.lang)
        for code, label in (("zh", "中文"), ("en", "English")):
            tk.Radiobutton(
                row,
                text=label,
                value=code,
                variable=self.lang_var,
                command=self.on_language,
            ).pack(side="left")

        # -- display toggles: time display / tooltips --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "show"), width=14, anchor="w").pack(side="left")
        self.show_time_var = tk.BooleanVar(value=settings.show_time)
        self.show_tooltip_var = tk.BooleanVar(value=settings.show_tooltip)
        tk.Checkbutton(
            row,
            text=tr(lang, "show_time"),
            variable=self.show_time_var,
            command=self.on_show_time,
        ).pack(side="left")
        tk.Checkbutton(
            row,
            text=tr(lang, "show_tooltip"),
            variable=self.show_tooltip_var,
            command=self.on_show_tooltip,
        ).pack(side="left")

        # -- note speed (t_window = 3.0 / speed level) --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "note_speed"), width=14, anchor="w").pack(
            side="left"
        )
        self.speed_var = tk.IntVar(
            value=max(1, min(10, round(3.0 / settings.t_window)))
        )
        tk.Scale(
            row,
            from_=1,
            to=10,
            orient="horizontal",
            length=300,
            variable=self.speed_var,
            command=self.on_speed,
            label=tr(lang, "speed_hint"),
        ).pack(side="left")

        # -- sound offset --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "sound_offset"), width=14, anchor="w").pack(
            side="left"
        )
        self.offset_var = tk.IntVar(value=settings.sound_offset)
        tk.Scale(
            row,
            from_=-500,
            to=500,
            resolution=10,
            orient="horizontal",
            length=300,
            variable=self.offset_var,
            command=self.on_offset,
            label=tr(lang, "offset_hint"),
        ).pack(side="left")

        # -- note border width --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "note_border"), width=14, anchor="w").pack(
            side="left"
        )
        self.border_var = tk.IntVar(value=settings.note_border_width)
        tk.Scale(
            row,
            from_=0,
            to=3,
            orient="horizontal",
            length=300,
            variable=self.border_var,
            command=self.on_border,
            label=tr(lang, "border_hint"),
        ).pack(side="left")

        # -- note display style --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=(6, 2), padx=6)
        tk.Label(row, text=tr(lang, "note_style"), width=14, anchor="w").pack(
            side="left"
        )
        self.style_var = tk.IntVar(value=settings.note_style)
        style_frame = tk.Frame(row)
        style_frame.pack(side="left")
        for val, key in ((0, "style_auto"), (1, "style_game"), (2, "style_solid")):
            tk.Radiobutton(
                style_frame,
                text=tr(lang, key),
                value=val,
                variable=self.style_var,
                command=self.on_style,
                anchor="w",
            ).pack(fill="x")

        # -- MIDI output device --
        row = tk.Frame(tab_play)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "midi_device"), width=14, anchor="w").pack(
            side="left"
        )
        self.devices = get_midi_devices()
        self.device_names = [tr(lang, "default_device")] + [n for _, n in self.devices]
        self.device_var = tk.StringVar(value=self.device_names[0])
        for did, name in self.devices:
            if did == settings.device_id:
                self.device_var.set(name)
                break
        tk.OptionMenu(
            row, self.device_var, *self.device_names, command=self.on_device
        ).pack(side="left")

        # ================= tab 2: colors =================
        # -- background color --
        row = tk.Frame(tab_colors)
        row.pack(fill="x", pady=3, padx=6)
        tk.Label(row, text=tr(lang, "bg_color"), width=14, anchor="w").pack(side="left")
        self.bg_btn = tk.Button(row, width=4, relief="solid", command=self.pick_bg)
        self.bg_btn.pack(side="left")
        self._set_btn_color(self.bg_btn, settings.bg_color)

        # -- channel colors (left button = note color, right button = border color) --
        tk.Label(tab_colors, text=tr(lang, "channel_colors"), anchor="w").pack(
            fill="x", pady=(8, 2), padx=6
        )
        grid = tk.Frame(tab_colors)
        grid.pack(fill="x", padx=6)
        self.color_rows = []
        for ch in range(N_CHANNELS):
            r, c = ch % 8, ch // 8
            f = tk.Frame(grid)
            f.grid(row=r, column=c, sticky="w", padx=8, pady=2)
            tk.Label(f, text=f"{tr(lang, 'track')} {ch}", width=8, anchor="w").pack(
                side="left"
            )
            fill_btn = tk.Button(
                f, width=3, relief="solid", command=lambda ch=ch: self.pick_color(ch, 0)
            )
            fill_btn.pack(side="left", padx=1)
            border_btn = tk.Button(
                f, width=3, relief="solid", command=lambda ch=ch: self.pick_color(ch, 1)
            )
            border_btn.pack(side="left", padx=1)
            self.color_rows.append((fill_btn, border_btn))
            self._set_btn_color(fill_btn, settings.note_colors[ch])
            self._set_btn_color(border_btn, settings.note_border_colors[ch])

        # -- bottom buttons (always visible, outside the tabs) --
        bottom = tk.Frame(body)
        bottom.pack(fill="x", pady=(8, 0))
        self.btn_reset = tk.Button(
            bottom, text=tr(lang, "reset_defaults"), width=12, command=self.reset
        )
        self.btn_reset.pack(side="left")
        self.btn_close = tk.Button(
            bottom, text=tr(lang, "close"), width=12, command=self.close
        )
        self.btn_close.pack(side="right")

        self.root.protocol("WM_DELETE_WINDOW", self.close)

    # ---------- helpers ----------
    @staticmethod
    def _set_btn_color(btn, color):
        btn.configure(bg="#%02x%02x%02x" % (color.r, color.g, color.b))

    def on_language(self):
        lang = self.lang_var.get()
        if lang == self.settings.lang:
            return
        self.settings.lang = lang
        self.apply_cb()
        self.restart = True  # rebuild the window in the new language
        self.tab_index = self.notebook.index("current")
        self.root.destroy()

    def on_speed(self, v):
        self.settings.t_window = round(3.0 / int(v), 3)
        self.apply_cb()

    def on_offset(self, v):
        self.settings.sound_offset = int(v)
        self.apply_cb()

    def on_border(self, v):
        self.settings.note_border_width = int(v)
        self.apply_cb()

    def on_style(self):
        self.settings.note_style = int(self.style_var.get())
        self.apply_cb()

    def on_device(self, name):
        self.settings.device_id = -1
        for did, dname in self.devices:
            if dname == name:
                self.settings.device_id = did
                break
        self.apply_cb()

    def on_show_time(self):
        self.settings.show_time = bool(self.show_time_var.get())
        self.apply_cb()

    def on_show_tooltip(self):
        self.settings.show_tooltip = bool(self.show_tooltip_var.get())
        self.apply_cb()

    def pick_bg(self):
        c = self.settings.bg_color
        picked = colorchooser.askcolor(
            color=(c.r, c.g, c.b),
            parent=self.root,
            title=tr(self.settings.lang, "pick_bg_title"),
        )[0]
        if picked:
            self.settings.bg_color = pygame.Color(
                int(picked[0]), int(picked[1]), int(picked[2])
            )
            self._set_btn_color(self.bg_btn, self.settings.bg_color)
            self.apply_cb()

    def pick_color(self, ch, which):
        cur = (
            self.settings.note_colors[ch]
            if which == 0
            else self.settings.note_border_colors[ch]
        )
        picked = colorchooser.askcolor(color=(cur.r, cur.g, cur.b), parent=self.root)[0]
        if picked:
            color = pygame.Color(int(picked[0]), int(picked[1]), int(picked[2]))
            if which == 0:
                self.settings.note_colors[ch] = color
            else:
                self.settings.note_border_colors[ch] = color
            self._set_btn_color(self.color_rows[ch][which], color)
            self.apply_cb()

    def reset(self):
        self.settings.reset_defaults()
        self._set_btn_color(self.bg_btn, self.settings.bg_color)
        self.speed_var.set(max(1, min(10, round(3.0 / self.settings.t_window))))
        self.offset_var.set(self.settings.sound_offset)
        self.border_var.set(self.settings.note_border_width)
        self.style_var.set(self.settings.note_style)
        self.show_time_var.set(self.settings.show_time)
        self.show_tooltip_var.set(self.settings.show_tooltip)
        for ch, (fb, bb) in enumerate(self.color_rows):
            self._set_btn_color(fb, self.settings.note_colors[ch])
            self._set_btn_color(bb, self.settings.note_border_colors[ch])
        self.device_var.set(self.device_names[0])
        self.apply_cb()

    def close(self):
        self.root.destroy()

    def show(self):
        self.root.mainloop()


def show_settings_window(settings, apply_cb):
    """Open the settings window (blocks until closed); the caller saves afterwards.
    Rebuilds the window when the language is switched, keeping the active tab."""
    win = SettingsWindow(settings, apply_cb)
    while True:
        win.show()
        if not win.restart:
            break
        win = SettingsWindow(settings, apply_cb, initial_tab=win.tab_index)
