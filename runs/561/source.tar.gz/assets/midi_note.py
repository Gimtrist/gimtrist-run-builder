class MidiNote:
    id: int
    start: float
    end: float
    pitch: int
    velocity: int
    channel: int

    def __init__(
        self, id: int, start: float, end: float, pitch: int, velocity: int, channel: int
    ):
        self.id = id
        self.start = start
        self.end = end
        self.pitch = pitch
        self.velocity = velocity
        self.channel = channel
