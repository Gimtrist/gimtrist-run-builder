# midi_shower.py - Draw notes onto a surface.
import pygame


class MidiShower:
    """Draw notes on a surface: horizontal mode scrolls right to left,
    vertical mode scrolls bottom to top. The visible time window t_window
    determines note speed (smaller = faster)."""

    def __init__(
        self,
        surface,
        notes,
        note_lowest=45,
        note_highest=93,
        note_border_width=1,
        t_window=1.0,
        is_vertical=False,
    ):
        self._surface = surface
        self._notes = notes
        self._area = surface.get_rect()
        self._time = 0.0
        self._time_window = t_window
        self._note_lowest = note_lowest
        self._note_highest = note_highest
        self._note_border_width = note_border_width
        self._is_vertical = is_vertical

        self._note_colors = [pygame.Color(255, 255, 255) for _ in range(16)]
        self._note_border_colors = [pygame.Color(127, 127, 127) for _ in range(16)]

        self._note_style = (
            0  # 0=auto (border-only after start) 1=game-judged 2=always solid
        )
        self._judged = (
            None  # judgment flags indexed by note id (None = not in game mode)
        )

        # Bucket notes by whole second: _on_notes_id[t] = ids of notes starting in second t
        self._notes_by_id = sorted(self._notes, key=lambda x: x.id)
        self._on_notes_id = []
        for note in self._notes_by_id:
            for t in range(int(note.start), int(note.end) + 1):
                while len(self._on_notes_id) <= t:
                    self._on_notes_id.append([])
                self._on_notes_id[t].append(note.id)

    def set_surface(self, surface):
        self._surface = surface
        self._area = surface.get_rect()

    def set_vertical(self, is_vertical):
        self._is_vertical = is_vertical

    def set_time_window(self, t_window):
        self._time_window = max(0.05, t_window)

    def set_border_width(self, width):
        self._note_border_width = width

    def set_note_style(self, style):
        self._note_style = style

    def set_judged(self, judged):
        """Pass the judgment flag list (indexed by note id) in game mode, None otherwise."""
        self._judged = judged

    def apply_settings(self, s):
        """Apply colors, speed, border width and note style from a settings object."""
        for ch in range(16):
            self._note_colors[ch] = s.note_colors[ch]
            self._note_border_colors[ch] = s.note_border_colors[ch]
        self.set_time_window(s.t_window)
        self._note_border_width = s.note_border_width
        self._note_style = s.note_style

    def _is_border_only(self, note, t_start):
        if self._note_style == 2:
            return False  # always solid
        if self._note_style == 1 and self._judged is not None:
            return self._judged[
                note.id
            ]  # game mode: judged (incl. Miss) -> border-only
        return note.start < t_start  # auto: border-only after the note starts

    def _note_rect(self, note):
        w, h = self._area.width, self._area.height
        span = max(1, self._note_highest - self._note_lowest)
        if self._is_vertical:
            bottom = (
                self._area.bottom - (note.start - self._time) / self._time_window * h
            )
            top = self._area.bottom - (note.end - self._time) / self._time_window * h
            left = (note.pitch - self._note_lowest - 0.5) / span * w + self._area.left
            right = (note.pitch - self._note_lowest + 0.5) / span * w + self._area.left
        else:
            left = (note.start - self._time) / self._time_window * w + self._area.left
            right = (note.end - self._time) / self._time_window * w + self._area.left
            top = (self._note_highest - note.pitch - 0.5) / span * h + self._area.top
            bottom = (self._note_highest - note.pitch + 0.5) / span * h + self._area.top
        return pygame.Rect(left, top, right - left, bottom - top)

    def _draw_note(self, note, color, border_color, border_only):
        rect = self._note_rect(note)
        if not border_only:
            pygame.draw.rect(self._surface, color, rect)
        if self._note_border_width != 0:
            pygame.draw.rect(self._surface, border_color, rect, self._note_border_width)

    def _show(self):
        t_start = self._time
        t_end = self._time + self._time_window
        note_showed = [False] * len(self._notes_by_id)
        first = max(int(t_start), 0)
        last = min(int(t_end) + 1, len(self._on_notes_id))
        for t in range(first, last):
            for note_id in self._on_notes_id[t]:
                if not note_showed[note_id]:
                    note = self._notes_by_id[note_id]
                    self._draw_note(
                        note,
                        self._note_colors[note.channel],
                        self._note_border_colors[note.channel],
                        self._is_border_only(note, t_start),
                    )
                    note_showed[note_id] = True

    def update(self, t: float):
        self._time = t
        self._show()
