# midi_reader.py - Parse MIDI files with pretty_midi (plus a tempo-map fix).
import io
import struct
import warnings

from typing import List, Dict, Any

import pretty_midi

import midi_note


def _read_varlen(data, i):
    v = 0
    while True:
        b = data[i]
        i += 1
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80):
            return v, i


def _encode_varlen(v):
    bs = [v & 0x7F]
    v >>= 7
    while v:
        bs.append((v & 0x7F) | 0x80)
        v >>= 7
    return bytes(reversed(bs))


def _ensure_tempo_track0(data):
    """pretty_midi only reads SetTempo events from track 0; when tempo events live on
    other tracks (some DAWs write them there), note times are computed at the 120 BPM
    default and the song plays noticeably slow. This merges all tempo events into a
    synthetic track 0 before handing the file to pretty_midi."""
    if data[:4] != b"MThd" or len(data) < 14:
        return data
    ntrks = struct.unpack(">H", data[10:12])[0]
    tempi = []  # (track, tick, us_per_beat)
    i = 14
    for t in range(ntrks):
        if data[i : i + 4] != b"MTrk":
            break
        length = struct.unpack(">I", data[i + 4 : i + 8])[0]
        end = i + 8 + length
        i += 8
        tick = 0
        status = 0
        while i < end:
            delta, i = _read_varlen(data, i)
            tick += delta
            b = data[i]
            if b == 0xFF:  # meta event
                i += 1
                mtype = data[i]
                i += 1
                ln, i = _read_varlen(data, i)
                if mtype == 0x51 and ln == 3:  # FF 51 03 = Set Tempo
                    tempi.append((t, tick, int.from_bytes(data[i : i + 3], "big")))
                i += ln
            elif b in (0xF0, 0xF7):  # sysex, skip
                i += 1
                ln, i = _read_varlen(data, i)
                i += ln
            else:  # channel event (with running status)
                if b & 0x80:
                    status = b
                    i += 1
                if (status >> 4) in (0xC, 0xD):  # program/aftertouch carry 1 data byte
                    i += 1
                else:
                    i += 2
        i = end
    if not tempi or all(t == 0 for t, _, _ in tempi):
        return data  # no tempo events, or all already on track 0

    # New track 0: all tempo events sorted by tick + end-of-track marker
    track = bytearray()
    prev = 0
    for _, tick, us in sorted(tempi, key=lambda x: x[1]):
        track += _encode_varlen(tick - prev)
        track += bytes((0xFF, 0x51, 0x03)) + us.to_bytes(3, "big")
        prev = tick
    track += _encode_varlen(0) + b"\xff\x2f\x00"  # End of Track
    new_track = b"MTrk" + struct.pack(">I", len(track)) + bytes(track)
    header = data[:10] + struct.pack(">H", ntrks + 1) + data[12:14]
    return header + new_track + data[14:]


class MidiReader:
    _midi_data: pretty_midi.PrettyMIDI

    def __init__(self, file_path: str):
        with open(file_path, "rb") as f:
            data = f.read()
        data = _ensure_tempo_track0(data)
        with warnings.catch_warnings():
            # The original tracks still carry tempo events, which triggers a
            # pretty_midi warning; ignore it.
            warnings.simplefilter("ignore")
            self._midi_data = pretty_midi.PrettyMIDI(io.BytesIO(data))

    def get_instruments_info(self) -> List[Dict[str, Any]]:
        instruments_info = []
        channel = 0
        for instrument in self._midi_data.instruments:
            instruments_info.append(
                {
                    "program": instrument.program,
                    "is_drum": instrument.is_drum,
                    "name": instrument.name,
                    "channel": channel if not instrument.is_drum else 9,
                }
            )
            if not instrument.is_drum:
                channel += 1
                if channel == 9:
                    channel = 10
        return instruments_info

    def get_notes(self) -> List[midi_note.MidiNote]:
        notes = []
        channel = 0
        note_id = 0
        for instrument in self._midi_data.instruments:
            for note in instrument.notes:
                notes.append(
                    midi_note.MidiNote(
                        note_id,
                        note.start,
                        note.end,
                        note.pitch,
                        note.velocity,
                        channel if not instrument.is_drum else 9,
                    )
                )
                note_id += 1
            if not instrument.is_drum:
                channel += 1
                if channel == 9:
                    channel = 10
        return notes

    def get_pitch_bends(self) -> List[Dict[str, Any]]:
        pitch_bends = []
        channel = 0
        for instrument in self._midi_data.instruments:
            for pitch_bend in instrument.pitch_bends:
                pitch_bends.append(
                    {
                        "pitch": pitch_bend.pitch,
                        "time": pitch_bend.time,
                        "channel": channel if not instrument.is_drum else 9,
                    }
                )
            if not instrument.is_drum:
                channel += 1
                if channel == 9:
                    channel = 10
        return pitch_bends


if __name__ == "__main__":
    mr = MidiReader("midi_examples/MeowRag_MIDI.mid")
    print(mr.get_instruments_info())
    print(mr.get_notes())
    print(mr.get_pitch_bends())
