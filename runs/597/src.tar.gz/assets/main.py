from gui import main_window as mw


def main():
    main_window = mw.MainWindow(1000, 1000)
    main_window.run()


if __name__ == "__main__":
    main()
